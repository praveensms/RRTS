import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;

public class ShowRequirements extends HttpServlet {

	    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       PrintWriter out  = response.getWriter();
		   response.setContentType("text/html;charset=UTF-8");
			 //Getting the values from the form
       String eid = request.getParameter("eid");

       Supervisor supervisor = new Supervisor();
       LinkedList<Requirements> linklist = new LinkedList<Requirements>();
       linklist = supervisor.viewRRequest(request, response, eid);
       int i=0;
       out.println("<h1>" + eid + "</h1>");
       out.println("<table>");
       out.println("<tr><th>Requirement Id</th><th>Requirement Name</th><th>Requested Quantity</th><th>Enter Quantity to Approve</th></tr>");
			 out.println("<form action='approveRequest' method='GET'>");
       while(i< linklist.size()){
         Requirements req = new Requirements();
         req = linklist.get(i);
         out.println("<tr><td>");
         out.println("<br/ >" + req.getReq_id() + "<br/>");
         out.println("</td><td>");
         out.println("<br/ >" + req.getReq_name() + "<br/>");
         out.println("</td><td>");
         out.println("<br/ >" + req.getQuantity() + "<br/>");
				 out.println("</td><td>");
				 out.println("<input type='text' name='approve' placeholder='Enter Quantity' />");
				 out.println("<input type='hidden' name='req_id' value="+ req.getReq_id() +" />");
         out.println("<input type='hidden' name='quantity' value="+ req.getQuantity() +" />");
         out.println("</td></tr>");
         i++;
       }
			 out.println("<input type='hidden' name='eid' value="+ eid +" />");
       out.println("</table>");
			 out.println("<input type='submit' name='submit' value='Approve'></form>");
	    }

	    @Override
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		        processRequest(request, response);
	    }
	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		      processRequest(request, response);
	    }
}
