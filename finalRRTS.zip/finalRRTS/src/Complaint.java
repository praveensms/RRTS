import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Complaint extends HttpServlet
{

  private String cid;
  private String cname;
  private String cdesc;
  private String rdno;
  private String cond;
  private String clocation;


  static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
  static final String DB_URL = "jdbc:mysql://localhost/dbase";
  static final String USER = "root";
  static final String PASS = "ammu";

  //Setters
  public void setCid(String cid)
  {
    this.cid = cid;
  }
  public void setCname(String cname)
  {
    this.cname = cname;
  }
  public void setCdesc(String cdesc)
  {
    this.cdesc = cdesc;
  }
  public void setRdno(String rdno)
  {
    this.rdno = rdno;
  }
  public void setCond(String cond)
  {
    this.cond = cond;
  }
  public void setClocation(String clocation)
  {
    this.clocation = clocation;
  }

  //Getters
  public String getCid()
  {
    return cid;
  }
  public String getCname()
  {
    return cname;
  }
  public String getCdesc()
  {
    return cdesc;
  }
  public String getRdno()
  {
    return rdno;
  }
  public String getCond()
  {
    return cond;
  }
  public String getClocation()
  {
    return clocation;
  }

  public void viewComplaint(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //processRequest(request, response);
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();

    Connection conn = null;
    Statement stmt  = null;

    try {
      HttpSession sess = request.getSession(false);
      if (sess == null) {
        response.sendRedirect("login.jsp");
      } else {
        String s2 = (String)sess.getAttribute("USER");
        Resident resident = new Resident();
        resident.setRname(s2);

        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection(DB_URL, USER, PASS);
        stmt = conn.createStatement();

        String sql   = String.format("SELECT * FROM Complaint WHERE comp_id IN(SELECT comp_id FROM Posted WHERE rid IN(SELECT rid FROM Resident WHERE uname='%s'))", resident.getRname());
        ResultSet rs = stmt.executeQuery(sql);
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>RRTS - Road Repair Tracking Service</title>");
        out.println("</head>");
        out.println("<body>");
        while (rs.next()) {
          out.println("<table cellpadding='10' cellspacing='20' width='30%' >");
          out.println("<tr>");
          out.println("<td>");
          out.println("<h2 style='color:green'>");
          out.println(rs.getString(2));
          out.println("</h2>");
          out.println("<p>");
          String str = (String)rs.getString(3);
          int len    = str.length();
          if (len > 100) {
            out.print((rs.getString(3)).substring(0, 100));
            out.print("......");
          } else {
            out.println(rs.getString(3));
          }
          out.println("</p>");
          out.println("<table>");
          out.println("<tr>");
          out.println("<td>");
          out.println("<p>");
          out.println("<mark style='color:#9e4137; background-color:tan'>Road No:</mark>");
          out.println(rs.getString(4));
          out.println("</p>");
          out.println("</td>");
          out.println("<td>");
          out.println("<p>");
          out.println("<mark style='color:#9e4137; background-color:tan'>Condition:</mark>");
          out.println(rs.getString(5));
          out.println("</p>");
          out.println("</td>");
          out.println("<td>");
          out.println("<p>");
          out.println("<mark style='color:#9e4137; background-color:tan'>Location:</mark>");
          out.println(rs.getString(6));
          out.println("</p>");
          out.println("</td>");
          out.println("</table>");
          out.println(String.format("<a href='readComplaint.jsp?cid=%s'>Read More...</a>",rs.getString(1)));
          out.println("</table>");
        }
        out.println("</body>");
        out.println("</html>");

        stmt.close();
        conn.close();
      }
    } catch(SQLException se)
    {
      out.println("SQLException occurred.....\n");
    } catch (Exception e)
    {
      out.println("Exception occurred........\n");
    }
  }

  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //Do Nothing
    viewComplaint(request, response);
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }
}
