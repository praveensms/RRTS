import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;

public class ResReadComplaint extends HttpServlet {

	    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	   	static final String DB_URL = "jdbc:mysql://localhost/dbase";
	   	static final String USER = "root";
	   	static final String PASS = "ammu";

	    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       PrintWriter out  = response.getWriter();
		   response.setContentType("text/html;charset=UTF-8");

       String cid = request.getParameter("cid");

			 HttpSession session = request.getSession(true);
			 String userType = (String)session.getAttribute("TYPE");

			 LinkedList<Complaint> linkObj = new LinkedList<Complaint>();
			 Resident resident = new Resident();
			 if (userType.compareTo("Resident") == 0) {
				 linkObj = resident.readComplaint(request, response, cid);
			 }

        int len = linkObj.size(), i=0, j=1;
        while(i < len)
        {
					if (j%2 == 0) {
						out.println("<table cellpadding='10' cellspacing='20' width='30%' style='background-color:rgb(234, 200, 129);' >");
					}else{
						out.println("<table cellpadding='10' cellspacing='20' width='30%' style='background-color:rgb(234, 200, 174);' >");
					}
					j++;
          Complaint comp = new Complaint();
          comp = linkObj.get(i);
          out.println("<tr>");
          out.println("<td>");
          out.println("<h2 style='color:green'>");
          out.println(comp.getCname());
          out.println("</h2>");
          out.println("<p>");
          out.println(comp.getCdesc());
          out.println("</p>");
          out.println("<table>");
          out.println("<tr>");
          out.println("<td>");
          out.println("<p>");
          out.println("<mark style='color:#9e4137; background-color:tan'>Road No:</mark>");
          out.println(comp.getRdno());
          out.println("</p>");
          out.println("</td>");
          out.println("<td>");
          out.println("<p>");
          out.println("<mark style='color:#9e4137; background-color:tan'>Condition:</mark>");
          out.println(comp.getCond());
          out.println("</p>");
          out.println("</td>");
          out.println("<td>");
          out.println("<p>");
          out.println("<mark style='color:#9e4137; background-color:tan'>Location:</mark>");
          out.println(comp.getClocation());
          out.println("</p>");
          out.println("</td>");
					out.println("</table>");
          out.println("<table style='alignment:center; display:block;border-spacing: 100px 0'><td>");
					out.println("</td>"+"<td>");
					out.println("</td></table>");
          out.println("</table><br/>");
          i++;
        }
	    }

	    @Override
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		        processRequest(request, response);
	    }
	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		      processRequest(request, response);
	    }
}
