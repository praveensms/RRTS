import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;

public class SessionLogin extends HttpServlet {

	    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	   	static final String DB_URL = "jdbc:mysql://localhost/dbase";
	   	static final String USER = "root";
	   	static final String PASS = "ammu";

	    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       PrintWriter out  = response.getWriter();
		   response.setContentType("text/html;charset=UTF-8");
			 //Getting the values from the form
       String get_name = request.getParameter("uname");
			 String get_pass = request.getParameter("pass");
			 String remember = request.getParameter("rem");
       String type = request.getParameter("type");

			 if (type.compareTo("Resident") == 0) {
					Resident res = new Resident();
					res.logIn(request, response, get_name, get_pass, remember, type);
			 } else if (type.compareTo("Clerk") == 0) {
					Clerk clerk = new Clerk();
					clerk.logIn(request, response, get_name, get_pass, remember, type);
			 } else if (type.compareTo("Employee") == 0) {
					Employee employee = new Employee();
					employee.logIn(request, response, get_name, get_pass, remember, type);
			 } else if (type.compareTo("Supervisor") == 0) {
					Supervisor supervisor = new Supervisor();
					supervisor.logIn(request, response, get_name, get_pass, remember, type);
			 } else if (type.compareTo("Administrator") == 0) {
					Administrator admin = new Administrator();
					admin.logIn(request, response, get_name, get_pass, remember, type);
			 } else{
					Mayor mayor = new Mayor();
					mayor.logIn(request, response, get_name, get_pass, remember, type);
			 }
	    }

	    @Override
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		        processRequest(request, response);
	    }
	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		      processRequest(request, response);
	    }
}
