import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Resident extends HttpServlet
{

  private String rid;
  private String rname;
  private String remail;
  private String rpass;
  private String rphno;

  //Setters
  public void setRid(String rid){
    this.rid = rid;
  }
  public void setRname(String rname){
    this.rname = rname;
  }
  public void setRemail(String remail){
    this.remail = remail;
  }
  public void setRpass(String rpass){
    this.rpass = rpass;
  }
  public void setRphno(String rphno){
    this.rphno = rphno;
  }

  //Getters
  public String getRid(){
    return rid;
  }
  public String getRname(){
    return rname;
  }
  public String getRemail(){
    return remail;
  }
  public String getRpass(){
    return rpass;
  }
  public String getRphno(){
    return rphno;
  }

  static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
  static final String DB_URL = "jdbc:mysql://localhost/dbase";
  static final String USER = "root";
  static final String PASS = "ammu";


  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();
    response.setContentType("text/html");
    out.println("<!DOCTYPE html><html>");
    String func = null;
    func = request.getParameter("function");

    out.println("<body><div>");
    //Here we are including the html header file
    RequestDispatcher rd1 = request.getRequestDispatcher("header.jsp");
    rd1.include(request, response);

    boolean bool = loginStatus(request, response);
    if (bool) {
      RequestDispatcher rd2 = request.getRequestDispatcher("menuRes1.jsp");
      rd2.include(request, response);
    }else {
      RequestDispatcher rd3 = request.getRequestDispatcher("menuRes2.jsp");
      rd3.include(request, response);
    }
    out.println("</div><div style='background-color:#b5dcb3;clear:both'>");
    //Body of the html goes here
    //out.println("<div > <h1>This is the article</h1></div>");

    //out.println(func);
    //Checking the user functionality8
    if (func != null) {
      if (func.compareTo("postComplaint") == 0) {
        //Goto postComplaint method
      } else if (func.compareTo("viewComplaint") == 0) {
        //Goto viewComplaint method
        Complaint comp = new Complaint();
        comp.viewComplaint(request, response);
      } else if (func.compareTo("postFeedback") == 0) {
          //Goto postFeedback method

      } else if (func.compareTo("login") == 0) {
        //Goto login method

      } else if (func.compareTo("logout") == 0) {
        //Goto logout method
        boolean br = logOut(request, response);
      }
    }
    out.println("<div style='background-color:#b5dcb;clear:both'/>");

    //footer of the html goes Here
    out.println("<div id='footer'>");
    RequestDispatcher rd4 = request.getRequestDispatcher("footer.jsp");
    rd4.include(request, response);
    out.println("</div>");
    out.println("</body></html>");
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }

  public boolean loginStatus(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    HttpSession sess = request.getSession(true);
    if (sess.getAttribute("USER") != null) {
      return true;
    }else{
      return false;
    }
  }

  public boolean logOut(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();
    HttpSession session = request.getSession(false);
    int flag1 = 1;
    if (session != null) {
        session.invalidate();
        flag1 = 2;
        //out.println("Success");
    }else{
      //out.println("Failed!");
      flag1 =0;
    }
    Cookie cookie    = null;
    Cookie [] cookies = null;
    int flag = 0;
    cookies = request.getCookies();
    String temp = null;
    if (cookies != null)
    {
      for (int i=0; i < cookies.length ; i++)
      {
        cookie = cookies[i];
        temp = cookie.getName();
        if ((temp).compareTo("Log_Bool") == 0 || (temp).compareTo("Log_Type") == 0) {
          cookie.setMaxAge(0);
          response.addCookie(cookie);
          flag = 5;
        }
      }
    }
    if (flag == 5 || flag1 == 2)
    {
      //out.println("you have successfully logged out!");
      response.sendRedirect("logout.jsp?logout=true");
      //out.println("Logged out successfully");
      return true;
    } else
    {
      //out.println("you have not logged out!");
      response.sendRedirect("logout.jsp?logout=false");
      //out.println("Logged out not success");
      return false;
    }
  }

  public boolean logIn(HttpServletRequest request, HttpServletResponse response, String uname, String pass, String rem, String types) throws ServletException, IOException
  {
    PrintWriter out  = response.getWriter();
    response.setContentType("text/html;charset=UTF-8");
    //Getting the values from the form
    String get_name = uname;
    String get_pass = pass;
    String remember = rem;
    String type = types;
    String str  = new String("remember");
    String str1 = new String("null");

    Connection conn = null;
    PreparedStatement stmt = null;
    try{
       Class.forName("com.mysql.jdbc.Driver");
       conn = DriverManager.getConnection(DB_URL,USER,PASS);
       //Checking the user credintials to login
       stmt = conn.prepareStatement(String.format("SELECT * FROM "+ type +" WHERE uname = ? and pass = ?"));
       stmt.setString(1, get_name);
       stmt.setString(2, get_pass);
       ResultSet rs = stmt.executeQuery();
       if (rs.next()) {
         setRname(get_name);
         out.println("Success login");
         HttpSession session = request.getSession(true);
         session.setAttribute("USER", get_name);
         session.setAttribute("TYPE", type);
         //Remembering the user details in cookies
         if (remember.compareTo(str) == 0) {
           Cookie cookie  = new Cookie("Log_Bool", get_name);;
           Cookie cookie1 = new Cookie("Log_Type", type);
           cookie1.setMaxAge(60*60*24);
           cookie.setMaxAge(60*60*24);
           response.addCookie(cookie1);
           response.addCookie(cookie);
         } if (remember.compareTo(str1) == 0)
         {
           //out.println("You're logged in, but you are not saved your local credintials!");
         }
         //response.sendRedirect("/finalRRTS");
         response.sendRedirect("loginStatus.jsp?login=true");
       }else{
         response.sendRedirect("loginStatus.jsp?login=false");
         //out.println("Failed login");
       }
    }catch(SQLException se){
       out.println("SQL Exception occurred.........");
       //response.sendRedirect("errorSQL.jsp");
    }catch(Exception e){
      //out.println("Exception occurred .............");
      response.sendRedirect("loginStatus.jsp?login=true");
    }
    return true;

  }
  public void postFeedback(HttpServletRequest request, HttpServletResponse response, String desc, String rating) throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();
    HttpSession session = request.getSession(true);

    String feed = desc;
    String rate = rating;

    Connection conn  = null;
    Connection conn1 = null;
    PreparedStatement stmt  = null;
    PreparedStatement stmt1 = null;
    PreparedStatement stmt2 = null;
      try{
      Class.forName("com.mysql.jdbc.Driver");
      conn = DriverManager.getConnection(DB_URL, USER, PASS);
      String user_name = (String)session.getAttribute("USER");

      stmt = conn.prepareStatement(String.format("SELECT rid FROM Resident WHERE uname=?"));
      stmt.setString(1, user_name);
      ResultSet rs = stmt.executeQuery();
      rs.next();
      int user_id   = rs.getInt(1);
      stmt2 = conn.prepareStatement(String.format("INSERT INTO FeedBack(rid, fdesc, rating) VALUES(?, ?, ?)"));
      stmt2.setInt(1, user_id);
      stmt2.setString(2, feed);
      stmt2.setString(3, rate);
      int w = 0;
      w = stmt2.executeUpdate();
      if (w != 0) {
        out.println("Success..");
      }else{
        out.println("Failed...");
      }
      stmt.close();
      rs.close();
      conn.close();
    }catch(SQLException se){
      out.println("SQLException occurred...");
    }catch(Exception e){
      out.println("Exception occurred...");
    }
  }
  public void postComplaint(HttpServletRequest request, HttpServletResponse response, String cname, String complaint,
                            String roadNo, String Area, String Condition) throws ServletException, IOException
  {
    //In this method we are posting the Resident COmplaint
    boolean log_check = loginStatus(request, response);
    if (log_check) {
      PrintWriter out = response.getWriter();

      String cnam = cname;
      String comp = complaint;
      String rdno = roadNo;
      String area = Area;
      String cond = Condition;

      Connection conn  = null;
      Connection conn1 = null;
      PreparedStatement stmt  = null;
      PreparedStatement stmt2 = null;
      PreparedStatement stmt3 = null;
      PreparedStatement stmt4 = null;

      try {
        Class.forName("com.mysql.jdbc.Driver");
        conn  = DriverManager.getConnection(DB_URL, USER, PASS);
        conn1 = DriverManager.getConnection(DB_URL, USER, PASS);

        int qs = 0;
        stmt = conn.prepareStatement(String.format("INSERT INTO Complaint(comp_name, comp_desc, comp_rno, comp_cond, comp_loc) VALUES (?, ?, ?, ?, ?)"));
        stmt.setString(1, cnam);
        stmt.setString(2, comp);
        stmt.setString(3, rdno);
        stmt.setString(4, cond);
        stmt.setString(5, area);
        qs = stmt.executeUpdate();
        if (qs != 0){
          HttpSession sess = request.getSession(false);

          out.println("Successfully posted complaint...");
          stmt = conn.prepareStatement(String.format("SELECT comp_id FROM Complaint WHERE comp_desc=?"));
          stmt.setString(1, comp);
          ResultSet rs = stmt.executeQuery();
          rs.next();
          String s1 = (String)rs.getString(1);
          out.println(s1);
          String s2 = (String)sess.getAttribute("USER");
          setRname(s2);

          stmt2   = conn.prepareStatement(String.format("SELECT rid FROM Resident WHERE uname=?"));
          stmt2.setString(1, getRname());
          ResultSet rs2 = stmt2.executeQuery();
          rs2.next();
          String s3  = (String)rs2.getString(1);
          setRid(s3);

          stmt4  = conn1.prepareStatement("SELECT * FROM Posted WHERE comp_id=? AND rid=?");
          stmt4.setString(1, s1);
          stmt4.setString(2, getRid());
          ResultSet rs3= stmt4.executeQuery();

          out.println("Checking the text");
          if (rs3.next()) {
            out.println("You have duplicate entries");
          }else{
            stmt3  = conn1.prepareStatement("INSERT INTO Posted(comp_id, rid) VALUES (?, ?)");
            stmt3.setString(1, s1);
            stmt3.setString(2, getRid());
            int qp = 0;
            qp = stmt3.executeUpdate();
            if (qp != 0) {
              out.println("Successfully inserted in the Posted Table");
            } else {
              out.println("Not inserted in Posted table");
            }
          }
          rs.close();
        } else {
          out.println("Not posted your complaint");
        }

        stmt.close();
        conn.close();
      } catch(SQLException se)
      {
        out.println("SQLException occurred.....\n");
      } catch (Exception e)
      {
        out.println("Exception occurred........\n");
      }
    }else{
      response.sendRedirect("login.jsp");
    }
  }
  public LinkedList viewComplaint(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();

    LinkedList<Complaint> linklist = new LinkedList<Complaint>();

    Connection conn  = null;
    PreparedStatement stmt = null;
    if (true ) {
      if (true) {
        try {
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          HttpSession session = request.getSession(true);
          String user = (String)session.getAttribute("USER");
          setRid(user);
          stmt = conn.prepareStatement("SELECT * FROM Complaint WHERE comp_id IN(SELECT comp_id FROM Posted WHERE rid IN(SELECT rid FROM Resident WHERE uname=?))");
          stmt.setString(1, getRid());
          ResultSet rs = stmt.executeQuery();

          while (rs.next())
          {
            Complaint complaint = new Complaint();
            String comp_id   = (String)rs.getString(1);
            String comp_name = (String)rs.getString(2);
            String comp_desc = (String)rs.getString(3);
            String comp_rdno = (String)rs.getString(4);
            String comp_cond = (String)rs.getString(5);
            String comp_loc  = (String)rs.getString(6);

            complaint.setCid(comp_id);
            complaint.setCname(comp_name);
            complaint.setCdesc(comp_desc);
            complaint.setRdno(comp_rdno);
            complaint.setCond(comp_cond);
            complaint.setClocation(comp_loc);

            linklist.add(complaint);
          }
        } catch(SQLException se)
        {
          out.println("SQLException occurred....");
        } catch(Exception e)
        {
          out.println("Exception occurred//....");
        }
      } else {
        //Here we are redirecting if the user is not an employeee
        response.sendRedirect("login.jsp");
      }
    }else{
      //Here we are redirecting if the user is not logged in
      response.sendRedirect("login.jsp");
    }
    return linklist;
  }
  public LinkedList readComplaint(HttpServletRequest request, HttpServletResponse response, String cid) throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();

    LinkedList<Complaint> linklist = new LinkedList<Complaint>();

    Connection conn  = null;
    PreparedStatement stmt = null;
    if (loginStatus(request, response)) {
      if (true) {
        try {
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          HttpSession session = request.getSession(true);
          String user = (String)session.getAttribute("USER");
          setRid(user);
          stmt = conn.prepareStatement("SELECT * FROM Complaint WHERE comp_id=?");
          stmt.setString(1, cid);
          ResultSet rs = stmt.executeQuery();

          while (rs.next())
          {
            Complaint complaint = new Complaint();
            String comp_id   = (String)rs.getString(1);
            String comp_name = (String)rs.getString(2);
            String comp_desc = (String)rs.getString(3);
            String comp_rdno = (String)rs.getString(4);
            String comp_cond = (String)rs.getString(5);
            String comp_loc  = (String)rs.getString(6);

            complaint.setCid(comp_id);
            complaint.setCname(comp_name);
            complaint.setCdesc(comp_desc);
            complaint.setRdno(comp_rdno);
            complaint.setCond(comp_cond);
            complaint.setClocation(comp_loc);

            linklist.add(complaint);
          }
        } catch(SQLException se)
        {
          out.println("SQLException occurred....");
        } catch(Exception e)
        {
          out.println("Exception occurred//....");
        }
      } else {
        //Here we are redirecting if the user is not an employeee
        response.sendRedirect("login.jsp");
      }
    }else{
      //Here we are redirecting if the user is not logged in
      response.sendRedirect("login.jsp");
    }
    return linklist;
  }
}
