import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class EmpRequestRequire extends HttpServlet
{
  static final String DB_Driver = "com.mysql.jdbc.Driver";
  static final String DB_Url = "jdbc:mysql://localhost/dbase";
  static final String DB_User = "root";
  static final String DB_Pass = "ammu";
  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
  {
    PrintWriter out = response.getWriter();
    response.setContentType("text/html");

    String[] require;
    String[] quantity;
    Employee employee = new Employee();

    if (request.getParameter("submit") != null && request.getParameterValues("require") != null
      && request.getParameterValues("quantity") != null) {
      require = request.getParameterValues("require");
      quantity = request.getParameterValues("quantity");

      for (int i=0; i<require.length; i++) {
        out.println(require[i]);
        out.println(quantity[i]);
      }

      out.println("<br/>Last one<br/>");
      boolean result = employee.requestRequire(request, response, require, quantity);
      out.println("<br/>Last one two three<br/>");
      if (result) {
        out.println("<br/>Inserted successfully.....");
      }else{
        out.println("<br/>Not Inserted successfully.....");
      }
    }else{
      out.println("You are not submitting any values to this Method.....");
    }

  }
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
  {
    processRequest(request, response);
  }
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
  {
    processRequest(request, response);
  }
}
