import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;

public class ViewComplaint extends HttpServlet {

	    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	   	static final String DB_URL = "jdbc:mysql://localhost/dbase";
	   	static final String USER = "root";
	   	static final String PASS = "ammu";

	    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       PrintWriter out  = response.getWriter();
		   response.setContentType("text/html;charset=UTF-8");

			 HttpSession session = request.getSession(true);
			 String userType = (String)session.getAttribute("TYPE");

			 LinkedList<Complaint> linkObj = new LinkedList<Complaint>();
			 Resident resident = new Resident();
			 Employee employee = new Employee();
			 int emp=0;
			 if (userType.compareTo("Resident") == 0) {
				 linkObj = resident.viewComplaint(request, response);
			 } else {
				 emp = 1;
				 linkObj = employee.viewComplaint(request, response);
			 }

        int len = linkObj.size(), i=0, j=1;
        while(i < len)
        {
					if (j%2 == 0) {
						out.println("<table cellpadding='10' cellspacing='20' width='30%' style='background-color:rgb(234, 200, 129);' >");
					}else{
						out.println("<table cellpadding='10' cellspacing='20' width='30%' style='background-color:rgb(234, 200, 174);' >");
					}
					j++;
          Complaint comp = new Complaint();
          comp = linkObj.get(i);
          out.println("<tr>");
          out.println("<td>");
          out.println("<h2 style='color:green'>");
          out.println(comp.getCname());
          out.println("</h2>");
          out.println("<p>");
					int num = comp.getCdesc().length();
					if (num > 80) {
						num = 80;
					}
					String modified = comp.getCdesc().substring(0,num);
          out.println(modified + "....");
          out.println("</p>");
          out.println("<table>");
          out.println("<tr>");
					out.println("</table>");
          out.println("<table style='alignment:center; display:block;border-spacing: 100px 0'><td>");
					out.println(String.format("<ul><li><a href='readComplaint.jsp?cid=%s'>Read More...</a></li></ul>",comp.getCid()));
					out.println("</td>"+"<td>");
					if (emp == 1) {
						out.println(String.format("<ul><li><a href='updateStatus.jsp?cid=%s'>Update Status</a></li></ul>",comp.getCid()));
					}
					out.println("</td></table>");
          out.println("</table><br/>");
          i++;
        }
	    }

	    @Override
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		        processRequest(request, response);
	    }
	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		      processRequest(request, response);
	    }
}
