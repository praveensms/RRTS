import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;

public class SupAppRequire extends HttpServlet {

	    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       PrintWriter out  = response.getWriter();
		   response.setContentType("text/html;charset=UTF-8");
			 //Getting the values from the form

       HttpSession session = request.getSession(true);
       String sname = (String)session.getAttribute("USER");

       Supervisor sup = new Supervisor();
       LinkedList<Requirements> linklist = new LinkedList<Requirements>();
       linklist = sup.approvedRequests(request, response, sname);
       int i=0;
       out.println("<h1>" + sname + "</h1>");
       out.println("<table>");
       out.println("<tr><th>Requirement Id</th><th>Requirement Name</th><th>Requested Quantity</th><th>Approved Quantity</th></tr>");
       while(i< linklist.size()){
         Requirements req = new Requirements();
         req = linklist.get(i);
         out.println("<tr><td>");
         out.println("<br/ >" + req.getReq_id() + "<br/>");
         out.println("</td><td>");
         out.println("<br/ >" + req.getReq_name() + "<br/>");
         out.println("</td><td>");
         out.println("<br/ >" + req.getQuantity() + "<br/>");
         out.println("</td><td>");
         if ( req.getApproved() == 0) {
           out.println("<br/ >Approval Pending<br/>");
         }else{
           out.println("<br/ >" + req.getApproved() + "<br/>");
         }
         out.println("</td></tr>");
         i++;
       }
       out.println("</table>");
	    }

	    @Override
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		        processRequest(request, response);
	    }
	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		      processRequest(request, response);
	    }
}
