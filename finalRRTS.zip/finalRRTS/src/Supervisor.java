import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Supervisor extends HttpServlet
{

  private String sid;
  private String sname;
  private String semail;
  private String spass;
  private String sphno;

  //Setters
  public void setSid(String sid){
    this.sid = sid;
  }
  public void setSname(String Sname){
    this.sname = sname;
  }
  public void setEemail(String semail){
    this.semail = semail;
  }
  public void setSpass(String Spass){
    this.spass = Spass;
  }
  public void setSphno(String Sphno){
    this.sphno = Sphno;
  }

  //Getters
  public String getSid(){
    return sid;
  }
  public String getSname(){
    return sname;
  }
  public String getSemail(){
    return semail;
  }
  public String getSpass(){
    return spass;
  }
  public String getSphno(){
    return sphno;
  }

  static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
  static final String DB_URL = "jdbc:mysql://localhost/dbase";
  static final String USER = "root";
  static final String PASS = "ammu";

  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //Do Nothing
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }

  public boolean loginStatus(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    HttpSession sess = request.getSession(true);
    if (sess.getAttribute("USER") != null) {
      return true;
    }else{
      return false;
    }
  }

  public boolean isSupervisor(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    HttpSession sess = request.getSession(true);
    String userType = (String)sess.getAttribute("TYPE");
    if ( userType.compareTo("Supervisor") == 0) {
      return true;
    }else{
      return false;
    }
  }

  public boolean logOut(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();
    HttpSession session = request.getSession(false);
    int flag1 = 1;
    if (session != null) {
        session.invalidate();
        flag1 = 2;
        //out.println("Success");
    }else{
      //out.println("Failed!");
      flag1 =0;
    }
    Cookie cookie    = null;
    Cookie [] cookies = null;
    int flag = 0;
    cookies = request.getCookies();
    String temp = null;
    if (cookies != null)
    {
      for (int i=0; i < cookies.length ; i++)
      {
        cookie = cookies[i];
        temp = cookie.getName();
        if ((temp).compareTo("Log_Bool") == 0 || (temp).compareTo("Log_Type") == 0) {
          cookie.setMaxAge(0);
          response.addCookie(cookie);
          flag = 5;
        }
      }
    }
    if (flag == 5 || flag1 == 2)
    {
      //out.println("you have successfully logged out!");
      response.sendRedirect("logout.jsp?logout=true");
      //out.println("Logged out successfully");
      return true;
    } else
    {
      //out.println("you have not logged out!");
      response.sendRedirect("logout.jsp?logout=false");
      //out.println("Logged out not success");
      return false;
    }
  }

  public boolean logIn(HttpServletRequest request, HttpServletResponse response, String uname, String pass, String rem, String types) throws ServletException, IOException
  {
    PrintWriter out  = response.getWriter();
    response.setContentType("text/html;charset=UTF-8");
    //Getting the values from the form
    String get_name = uname;
    String get_pass = pass;
    String remember = rem;
    String type = types;
    String str  = new String("remember");
    String str1 = new String("null");

    Connection conn = null;
    PreparedStatement stmt = null;
    try{
       Class.forName("com.mysql.jdbc.Driver");
       conn = DriverManager.getConnection(DB_URL,USER,PASS);
       //Checking the user credintials to login
       stmt = conn.prepareStatement(String.format("SELECT * FROM "+ type +" WHERE uname = ? and pass = ?"));
       stmt.setString(1, get_name);
       stmt.setString(2, get_pass);
       ResultSet rs = stmt.executeQuery();
       if (rs.next()) {
         setSname(get_name);
         out.println("Success login");
         HttpSession session = request.getSession(true);
         session.setAttribute("USER", get_name);
         session.setAttribute("TYPE", type);
         //Remembering the user details in cookies
         if (remember.compareTo(str) == 0) {
           Cookie cookie  = new Cookie("Log_Bool", getSname());;
           Cookie cookie1 = new Cookie("Log_Type", type);
           cookie1.setMaxAge(60*60*24);
           cookie.setMaxAge(60*60*24);
           response.addCookie(cookie1);
           response.addCookie(cookie);
         } if (remember.compareTo(str1) == 0)
         {
           //out.println("You're logged in, but you are not saved your local credintials!");
         }
         response.sendRedirect("loginStatus.jsp?login=true");
         //response.sendRedirect("/finalRRTS");
       }else{
         response.sendRedirect("loginStatus.jsp?login=false");
         //out.println("Failed login");
       }
    }catch(SQLException se){
       out.println("SQL Exception occurred.........");
       //response.sendRedirect("errorSQL.jsp");
    }catch(Exception e){
      //out.println("Exception occurred .............");
      response.sendRedirect("loginStatus.jsp?login=true");
    }
    return true;

  }
  public LinkedList viewComplaint(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //In this method we are posting the Resident COmplaint
    boolean log_check = loginStatus(request, response);
    boolean issupervisor= isSupervisor(request, response);
    PrintWriter out = response.getWriter();

    LinkedList<Complaint> linklist = new LinkedList<Complaint>();

    Connection conn  = null;
    PreparedStatement stmt = null;
    LinkedList list = new LinkedList();
    if (true ) {
      if (true) {
        try {
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          stmt = conn.prepareStatement("SELECT * FROM Complaint");
          ResultSet rs = stmt.executeQuery();

          while (rs.next())
          {
            Complaint complaint = new Complaint();
            String comp_id   = (String)rs.getString(1);
            String comp_name = (String)rs.getString(2);
            String comp_desc = (String)rs.getString(3);
            String comp_rdno = (String)rs.getString(4);
            String comp_cond = (String)rs.getString(5);
            String comp_loc  = (String)rs.getString(6);

            complaint.setCid(comp_id);
            complaint.setCname(comp_name);
            complaint.setCdesc(comp_desc);
            complaint.setRdno(comp_rdno);
            complaint.setCond(comp_cond);
            complaint.setClocation(comp_loc);

            linklist.add(complaint);
          }
        } catch(SQLException se)
        {
          out.println("SQLException occurred....");
        } catch(Exception e)
        {
          out.println("Exception occurred//....");
        }
      } else {
        //Here we are redirecting if the user is not an Supervisor
        response.sendRedirect("login.jsp");
      }
    }else{
      //Here we are redirecting if the user is not logged in
      response.sendRedirect("login.jsp");
    }
    return linklist;
  }
  public boolean scheduleReport(HttpServletRequest request, HttpServletResponse response, String comp_id,
            String stDate,  String endDate ) throws ServletException, IOException
  {
    //In this method we are posting the Resident Complaint
    boolean log_check = loginStatus(request, response);
    boolean issupervisor= isSupervisor(request, response);
    PrintWriter out = response.getWriter();

    if (log_check) {
      if (issupervisor) {
        Connection conn  = null;
        Connection conn1 = null;
        PreparedStatement stmt  = null;
        PreparedStatement stmt1 = null;
        PreparedStatement stmt2 = null;
        PreparedStatement stmt3 = null;
        try{
          Class.forName("com.mysql.jdbc.Driver");
          conn  = DriverManager.getConnection(DB_URL, USER, PASS);
          conn1 = DriverManager.getConnection(DB_URL, USER, PASS);

          HttpSession session = request.getSession(true);
          String username = (String)session.getAttribute("USER");
          out.println(username);

          stmt = conn.prepareStatement("INSERT INTO Schedule (sc_st_date, sc_end_date) VALUES (?, ?)");
          stmt.setString(1, stDate);
          stmt.setString(2, endDate);
          int q = 0;
          out.println("Gpood Bye to the wt;;;");
          q = stmt.executeUpdate();
          out.println("Welcome to the wt;;;");
          if (q != 0) {
            out.println("Schedule inserted successfully....");
            stmt1 = conn.prepareStatement("SELECT sc_id FROM Schedule WHERE sc_st_date=? and sc_end_date=?");
            stmt1.setString(1, stDate);
            stmt1.setString(2, endDate);
            ResultSet rs = stmt1.executeQuery();
            rs.next();
            String sc_id = rs.getString(1);

            stmt2 = conn.prepareStatement("SELECT eid FROM Supervisor WHERE uname=?");
            stmt2.setString(1, username);
            ResultSet rs1 = stmt2.executeQuery();
            rs1.next();
            String eid = rs1.getString(1);

            stmt3 = conn.prepareStatement("INSERT INTO Prepare VALUES (?, ?, ?)");
            stmt3.setString(1, comp_id);
            stmt3.setString(2, eid);
            stmt3.setString(3, sc_id);
            int w = 0;
            w = stmt3.executeUpdate();
            if (w != 0) {
              out.println("Schedule prepared successfully....");
            }else{
              out.println("Schedule not prepared../..........");
            }
          }

        }
        catch(SQLException se){
          out.println("SQLException occurred...");
        }
        catch(Exception e){
          out.println("Exception occurred......");
        }
      }else{
        out.println("You are not an Supervisore.....");
      }
    }else{
      out.println("You are not logged in.....");
    }
    return true;
  }
  public LinkedList viewRRequest(HttpServletRequest request, HttpServletResponse response, String eid) throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();

    LinkedList<Requirements> linklist = new LinkedList<Requirements>();
    //Here we are checking if the user logged in or not
    if (loginStatus(request, response)) {
      //Here we are checking the user is Supervisor or not
      if (isSupervisor(request, response)) {
        Connection conn = null;
        PreparedStatement stmt  = null;
        PreparedStatement stmt1 = null;

        try{
          //Try statement will execute Hereout
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          stmt1 = conn.prepareStatement("SELECT * FROM Requirements");
          ResultSet rs1 = stmt1.executeQuery();
          LinkedList list = new LinkedList();
          while(rs1.next()){
            list.add(rs1.getString(2));
          }

          stmt = conn.prepareStatement("SELECT * FROM Emp_Req WHERE eid=?");
          stmt.setString(1, eid);
          ResultSet rs = stmt.executeQuery();
          while(rs.next()){
            Requirements req = new Requirements();
            String rid = (String)rs.getString("req_id");
            int quant = rs.getInt("quantity");
            String name = (String)list.get(Integer.parseInt(rid) - 1);
            req.setReq_name(name);
            req.setReq_id(rid);
            req.setQuantity(quant);
            linklist.add(req);
          }

        }catch(SQLException se){
          out.println("SQLException occurred...");
        }catch(Exception e){
          out.println("Exception occurred...");
        }
      }
    }else{
      out.println("You are not logged in......");
    }
    return linklist;
  }
  public LinkedList viewREmployee(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //Completed
    PrintWriter out = response.getWriter();
    LinkedList<Employee> linklist = new LinkedList<Employee>();
    //Here we are checking if the user logged in or not
    if (loginStatus(request, response)) {
      //Here we are checking the user is Supervisor or not
      if (isSupervisor(request, response)) {
        Connection conn = null;
        PreparedStatement stmt = null;

        try{
          //Try statement will execute here
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          stmt = conn.prepareStatement("SELECT DISTINCT(eid) FROM Emp_Req");
          ResultSet rs = stmt.executeQuery();

          while( rs.next() ){
            Employee emp = new Employee();
            emp.setEid(rs.getString(1));
            linklist.add(emp);
          }

        }catch(SQLException se){
          out.println("SQLException occurred...");
        }catch(Exception e){
          out.println("Exception occurred...");
        }
      }
    }else{
      out.println("You are not logged in......");
    }
    return linklist;
  }
  public boolean approveRequest(HttpServletRequest request, HttpServletResponse response, LinkedList<Requirements> linklist,
                  int eid) throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();
    //Here we are checking if the user logged in or not
    if (loginStatus(request, response)) {
      //Here we are checking the user is Supervisor or not
      if (isSupervisor(request, response)) {
        Connection conn = null;
        PreparedStatement stmt  = null;
        PreparedStatement stmt1 = null;

        try{
          //Try statement will execute Hereout
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          HttpSession sess = request.getSession(true);
          String user = (String)sess.getAttribute("USER");
          stmt1 = conn.prepareStatement("SELECT sid from Supervisor  WHERE uname=?");
          stmt1.setString(1, user);
          ResultSet rs = stmt1.executeQuery();
          rs.next();
          int sid = rs.getInt(1);

          int i =0;
          while (i < linklist.size()){
            Requirements req = new Requirements();
            req = linklist.get(i);
            String req_id = req.getReq_id();
            int quant  = req.getQuantity();
            int approve= req.getApproved();

            stmt = conn.prepareStatement("UPDATE Emp_Req SET ap_req=?, sid=?, granted=? WHERE eid=? and req_id=? and quantity=?");
            stmt.setString(1, "Approved");
            stmt.setInt(2, sid);
            stmt.setInt(3, approve);
            stmt.setInt(4, eid);
            stmt.setString(5, req_id);
            stmt.setInt(6, quant);
            out.println("<br/>Approve:"+"Approved");
            out.println("<br/>Sid:"+sid);
            out.println("<br/>Approve count:"+approve);
            out.println("<br/>Eid:"+eid);
            out.println("<br/>Req_id:"+req_id);
            out.println("<br/>Quantity:"+quant);
            int q = 0;
            q = stmt.executeUpdate();
            if (q!=0) {
              out.println("Updated....");
            }else{
              out.println("Not Updated....");
            }
            i++;
          }
        }catch(SQLException se){
          out.println("SQLException occurred...");
        }catch(Exception e){
          out.println("Exception occurred...");
        }
      }else{
        out.println("You are not supervisor...");
      }
    }else{
      out.println("You are not logged in......");
    }
    return true;
  }
  public boolean requestRequire(HttpServletRequest request, HttpServletResponse response, String[] require,
            String[] quantity) throws ServletException, IOException
  {
    //In this method we are posting the Resident Complaint
    boolean log_check = loginStatus(request, response);
    boolean issupervisor= isSupervisor(request, response);
    PrintWriter out = response.getWriter();

    if (log_check) {
      if (issupervisor) {
        Connection conn  = null;
        Connection conn1 = null;
        PreparedStatement stmt  = null;
        PreparedStatement stmt1 = null;
        PreparedStatement stmt2 = null;
        PreparedStatement stmt3 = null;
        try{
          Class.forName("com.mysql.jdbc.Driver");
          conn  = DriverManager.getConnection(DB_URL, USER, PASS);
          conn1 = DriverManager.getConnection(DB_URL, USER, PASS);

          HttpSession session = request.getSession(true);
          String username = (String)session.getAttribute("USER");
          out.println(username);
          out.println("<br/>Exception before first statement<br/>");
          stmt = conn.prepareStatement("SELECT * FROM Supervisor WHERE uname=?");
          stmt.setString(1, username);
          ResultSet rs = stmt.executeQuery();
          out.println("<br/>Exception after first statement<br/>");
          rs.next();
          int sid = rs.getInt(1);
          out.println("Eid is " + sid + "<br/> String len: "+require.length);

          for (int i=0; i<require.length; i++) {
            out.println("<br/>Exception before second statement<br/>");

            stmt2 = conn.prepareStatement("SELECT * FROM Sup_Req WHERE sid=? and req_id=?");
            stmt2.setInt(1, sid);
            stmt2.setString(2, require[i]);
            out.println("<br/>Exception after second statement<br/>");
            ResultSet rs1 = stmt2.executeQuery();
            out.println("<br/>Exception after before second statement<br/>");
            if (rs1.next()) {
              out.println(rs1.getInt(5));
              int quant = Integer.parseInt(quantity[i]) + rs1.getInt(5);
              out.println("quantity :"+ quant);
              out.println("<br/>Before the Update");
              stmt3 = conn.prepareStatement("UPDATE Sup_Req SET quantity=? WHERE sid=? and req_id=?");
              stmt3.setInt(1, quant);
              stmt3.setInt(2, sid);
              stmt3.setString(3, require[i]);
              int w = 0;
              out.println("<br/>After the Update");
              w = stmt3.executeUpdate();
              out.println("<br/>After before the Update");
              if (w != 0) {
                out.println("Update Success");
              }
            }else{
              //Here we are inserting the Requirements in the table
              out.println("<br/>before the Insert");
              stmt1 = conn1.prepareStatement("INSERT INTO Sup_Req (sid, req_id, quantity) VALUES (?, ?, ?)");
              stmt1.setInt(1, sid);
              stmt1.setString(2, require[i]);
              stmt1.setString(3, quantity[i]);
              int q = 0;
              out.println("<br/>after the Insert");
              q = stmt1.executeUpdate();
              out.println("<br/>After before the Insert");
              out.println("<br/>Exception after second statement<br/>");
              if (q!=0 ) {
                out.println("<br/>Success<br/>");
              }
            }
          }
        }
        catch(SQLException se){
          out.println("SQLException occurred...");
        }
        catch(Exception e){
          out.println("Exception occurred......");
        }
      }else{
        out.println("You are not an Supervisor.....");
      }
    }else{
      out.println("You are not logged in.....");
    }
    return true;
  }
  public boolean assignComplaint(HttpServletRequest request, HttpServletResponse response,String compid,
                  int eid) throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();
    //Here we are checking if the user logged in or not
    if (loginStatus(request, response)) {
      //Here we are checking the user is Supervisor or not
      if (isSupervisor(request, response)) {
        Connection conn = null;
        PreparedStatement stmt  = null;
        PreparedStatement stmt1 = null;

        try{
          //Try statement will execute Hereout
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          HttpSession sess = request.getSession(true);
          String user = (String)sess.getAttribute("USER");

          stmt = conn.prepareStatement("SELECT sid FROM Supervisor WHERE uname=?");
          stmt.setString(1, user);
          ResultSet rs = stmt.executeQuery();
          rs.next();
          int sid = (int)rs.getInt(1);

          stmt1 = conn.prepareStatement("INSERT INTO Assign (comp_id, sid, eid) VALUES (?, ?, ?)");
          stmt1.setString(1, compid);
          stmt1.setInt(2, sid);
          stmt1.setInt(3, eid);
          int q = 0;
          q = stmt1.executeUpdate();
          if (q != 0) {
            out.println("<br/>Assigned successfully....");
          }else{
            out.println("<br/>Not Assigned successfully....");
          }
        }catch(SQLException se){
          out.println("SQLException occurred...");
        }catch(Exception e){
          out.println("Exception occurred...");
        }
      }else{
        out.println("You are not supervisor...");
      }
    }else{
      out.println("You are not logged in......");
    }
    return true;
  }
  public LinkedList approvedRequests(HttpServletRequest request, HttpServletResponse response, String sname) throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();
    LinkedList<Requirements> linklist  = new LinkedList<Requirements>();

    if (loginStatus(request, response)) {
      if (isSupervisor(request, response)) {

        Connection conn = null;
        PreparedStatement stmt  = null;
        PreparedStatement stmt1 = null;

        try{
          //Try statement will execute Hereout
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          stmt1 = conn.prepareStatement("SELECT * FROM Requirements");
          ResultSet rs1 = stmt1.executeQuery();
          LinkedList list = new LinkedList();
          while(rs1.next()){
            list.add(rs1.getString(2));
          }


          stmt1 = conn.prepareStatement("SELECT sid FROM Supervisor WHERE uname=?");
          stmt1.setString(1, sname);
          ResultSet rs2 = stmt1.executeQuery();
          rs2.next();
          int sid = rs2.getInt(1);

          stmt = conn.prepareStatement("SELECT * FROM Sup_Req WHERE sid=?");
          stmt.setInt(1, sid);
          ResultSet rs = stmt.executeQuery();
          while(rs.next()){
            Requirements req = new Requirements();
            //Getting values from ResultSet
            String rid = (String)rs.getString("req_id");
            int quant = rs.getInt("quantity");
            int approved = rs.getInt("granted");
            String name = (String)list.get(Integer.parseInt(rid) - 1);
            //Storing Values to Requirements class
            req.setReq_name(name);
            req.setReq_id(rid);
            req.setQuantity(quant);
            req.setApproved(approved);

            linklist.add(req);
          }

        }catch(SQLException se){
          out.println("SQLException occurred...");
        }catch(Exception e){
          out.println("Exception occurred...");
        }

      }else{
        out.println("<br/>You are not an Supervisor to view this...");
      }
    }else{
      out.println("<br/>You are not logged in to view this.....");
    }
    return linklist;
  }
}
