import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;

public class ShowEDetails extends HttpServlet {

	    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       PrintWriter out  = response.getWriter();
		   response.setContentType("text/html;charset=UTF-8");
			 //Getting the values from the form

       Supervisor supervisor = new Supervisor();
       LinkedList<Employee> linklist = new LinkedList<Employee>();
       linklist = supervisor.viewREmployee(request, response);
       int i=0;
       while(i< linklist.size()){
         Employee emp = new Employee();
         emp = linklist.get(i);
         out.println("<br/ ><a href='showRequirements.jsp?eid="+ emp.getEid() +"'>" + emp.getEid() + "</a><br/>");
         i++;
       }
	    }

	    @Override
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		        processRequest(request, response);
	    }
	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		      processRequest(request, response);
	    }
}
