import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Random;


public class MenuFinal extends HttpServlet
{
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
  {
    PrintWriter out = response.getWriter();
    response.setContentType("text/html");

    Cookie cookie    = null;
    Cookie [] cookies = null;

    int flag = 0, menu = 6;
    cookies = request.getCookies();

    String tempName = null;
    String tempValu = null;

    HttpSession session = request.getSession(false);
    String typ = null;
    try
    {
      typ = (String)session.getAttribute("TYPE");

      if (typ.compareTo("Mayor") == 0)
      {
        menu = 0;
      } else if (typ.compareTo("Administrator") == 0)
      {
        menu = 1;
      }else if (typ.compareTo("Supervisor") == 0)
      {
        menu = 2;
      }else if (typ.compareTo("Employee") == 0)
      {
        menu = 3;
      }else if (typ.compareTo("Clerk") == 0)
      {
        menu = 4;
      }else if (typ.compareTo("Resident") == 0)
      {
        menu = 5;
      } else
      {
        menu = 6;
      }
    }catch(NullPointerException nl)
    {
      //Do Nothing
    }
    out.println("<html><head><link rel='stylesheet' href='menu_style.css'></link></head><body>");
    switch(menu)
    {
      case 0:
      {
        out.println("<ul><li><a href='../finalRRTS'>Home</a></li><li><a href='viewComplaint.jsp'>View Complaint</a></li><li><a href='#View Request'>View Request</a></li><li><a href='#Mayer'>Mayer</a></li><li><a href='logout'>LogOut</a></li></ul>");
        break;
      }
      case 1:
      {
        out.println("<ul><li><a href='../finalRRTS'>Home</a></li><li><a href='showSDetails.jsp'>View Require</a></li><li><a href='viewComplaint.jsp'>View Complaint</a></li><li><a href='#Admin'>Admin</a></li><li><a href='logout'>LogOut</a></li></ul>");
        break;
      }
      case 2:
      {
        out.println("<ul><li><a href='../finalRRTS'>Home</a></li><li><a href='viewComplaint.jsp'>View Complaint</a></li><li><a href='assignComplaint.jsp'>Assign Complaint</a></li><li><a href='requirementRequests.jsp'>View Request</a></li><li><a href='supRequirements.jsp'>Request Requiremants</a></li><li><a href='supAppRequests.jsp'>Approved Requests</a></li><li><a href='logout'>LogOut</a></li></ul>");
        break;
      }
      case 3:
      {
        out.println("<ul><li><a href='../finalRRTS'>Home</a></li><li><a href='assignedComplaint.jsp'>Assigned Complaints</a></li><li><a href='scheduleReport.jsp'>Schedule Report</a></li><li><a href='updateComplaint.jsp'>Update Complaint</a></li><li><a href='requirements.jsp'>Request Require</a></li><li><a href='empAppRequests.jsp'>Approved Requests</a></li><li><a href='logout'>LogOut</a></li></ul>");
        break;
      }
      case 4:
      {
        out.println("<ul><li><a href='../finalRRTS'>Home</a></li><li><a href='clerkPostComplaint.jsp'>Post Complaint</a></li><li><a href='#Clerk'>Clerk</a></li><li><a href='logout'>LogOut</a></li></ul>");
        break;
      }
      case 5:
      {
        out.println("<ul><li><a href='../finalRRTS'>Home</a></li><li><a href='postComplaint.jsp'>Post Complaint</a></li><li><a href='viewComplaint.jsp'>View Complaint</a></li><li><a href='postFeedback.jsp'>Post FeedBack</a></li><li><a href='logout'>Resident</a></li><li><a href='logout'>LogOut</a></li></ul>");
        break;
      }
      case 6:
      {
        out.println("<ul><li><a href='../finalRRTS'>Home</a></li><li><a href='login.jsp'>Login</a></li><li><a href='signup.jsp'>Sign Up</a></li></ul>");
        break;
      }
    }
  }
}
