import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Employee extends HttpServlet
{

  private String eid;
  private String ename;
  private String eemail;
  private String epass;
  private String ephno;

  //Setters
  public void setEid(String eid){
    this.eid = eid;
  }
  public void setEname(String rname){
    this.ename = ename;
  }
  public void setEemail(String eemail){
    this.eemail = eemail;
  }
  public void setEpass(String epass){
    this.epass = epass;
  }
  public void setEphno(String ephno){
    this.ephno = ephno;
  }

  //Getters
  public String getEid(){
    return eid;
  }
  public String getEname(){
    return ename;
  }
  public String getEemail(){
    return eemail;
  }
  public String getEpass(){
    return epass;
  }
  public String getEphno(){
    return ephno;
  }

  static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
  static final String DB_URL = "jdbc:mysql://localhost/dbase";
  static final String USER = "root";
  static final String PASS = "ammu";

  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    /*PrintWriter out = response.getWriter();
    response.setContentType("text/html");
    out.println("<!DOCTYPE html><html>");
    String func = null;
    func = request.getParameter("function");

    out.println("<body><div>");
    //Here we are including the html header file
    RequestDispatcher rd1 = request.getRequestDispatcher("header.jsp");
    rd1.include(request, response);

    boolean bool = loginStatus(request, response);
    if (bool) {
      RequestDispatcher rd2 = request.getRequestDispatcher("menuEmp.jsp");
      rd2.include(request, response);
    }else {
      RequestDispatcher rd3 = request.getRequestDispatcher("menuRes2.jsp");
      rd3.include(request, response);
    }
    out.println("</div><div style='background-color:#b5dcb3;clear:both'>");
    //Body of the html goes here
    //out.println("<div > <h1>This is the article</h1></div>");

    //out.println(func);
    //Checking the user functionality8
    if (func != null) {
      if (func.compareTo("postComplaint") == 0) {
        //Goto postComplaint method
      } else if (func.compareTo("viewComplaint") == 0) {
        //Goto viewComplaint method
        LinkedList<Complaint> linkObj = new LinkedList<Complaint>();

        linkObj = viewComplaint(request, response);

        int len = linkObj.size(), i=0;
        while(i < len)
        {
          Complaint comp = new Complaint();
          comp = linkObj.get(i);
          out.println("<table cellpadding='10' cellspacing='20' width='30%' >");
          out.println("<tr>");
          out.println("<td>");
          out.println("<h2 style='color:green'>");
          out.println(comp.getCname());
          out.println("</h2>");
          out.println("<p>");
          out.println(comp.getCdesc());
          out.println("</p>");
          out.println("<table>");
          out.println("<tr>");
          out.println("<td>");
          out.println("<p>");
          out.println("<mark style='color:#9e4137; background-color:tan'>Road No:</mark>");
          out.println(comp.getRdno());
          out.println("</p>");
          out.println("</td>");
          out.println("<td>");
          out.println("<p>");
          out.println("<mark style='color:#9e4137; background-color:tan'>Condition:</mark>");
          out.println(comp.getCond());
          out.println("</p>");
          out.println("</td>");
          out.println("<td>");
          out.println("<p>");
          out.println("<mark style='color:#9e4137; background-color:tan'>Location:</mark>");
          out.println(comp.getClocation());
          out.println("</p>");
          out.println("</td>");
          out.println("</table>");
          out.println(String.format("<a href='readComplaint.jsp?cid=%s'>Read More...</a>",comp.getCid()));
          out.println("</table>");
          i++;
        }

      } else if (func.compareTo("postFeedback") == 0) {
          //Goto postFeedback method

      } else if (func.compareTo("login") == 0) {
        //Goto login method

      } else if (func.compareTo("logout") == 0) {
        //Goto logout method
        boolean br = logOut(request, response);
      }
    }
    out.println("<div style='background-color:#b5dcb;clear:both'/>");

    //footer of the html goes Here
    out.println("<div id='footer'>");
    RequestDispatcher rd4 = request.getRequestDispatcher("footer.jsp");
    rd4.include(request, response);
    out.println("</div>");
    out.println("</body></html>");*/
    //DO Nothing
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }

  public boolean loginStatus(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    HttpSession sess = request.getSession(true);
    if (sess.getAttribute("USER") != null) {
      return true;
    }else{
      return false;
    }
  }

  public boolean isEmployee(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    HttpSession sess = request.getSession(true);
    String userType = (String)sess.getAttribute("TYPE");
    if ( userType.compareTo("Employee") == 0) {
      return true;
    }else{
      return false;
    }
  }

  public boolean logOut(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();
    HttpSession session = request.getSession(false);
    int flag1 = 1;
    if (session != null) {
        session.invalidate();
        flag1 = 2;
        //out.println("Success");
    }else{
      //out.println("Failed!");
      flag1 =0;
    }
    Cookie cookie    = null;
    Cookie [] cookies = null;
    int flag = 0;
    cookies = request.getCookies();
    String temp = null;
    if (cookies != null)
    {
      for (int i=0; i < cookies.length ; i++)
      {
        cookie = cookies[i];
        temp = cookie.getName();
        if ((temp).compareTo("Log_Bool") == 0 || (temp).compareTo("Log_Type") == 0) {
          cookie.setMaxAge(0);
          response.addCookie(cookie);
          flag = 5;
        }
      }
    }
    if (flag == 5 || flag1 == 2)
    {
      //out.println("you have successfully logged out!");
      response.sendRedirect("logout.jsp?logout=true");
      //out.println("Logged out successfully");
      return true;
    } else
    {
      //out.println("you have not logged out!");
      response.sendRedirect("logout.jsp?logout=false");
      //out.println("Logged out not success");
      return false;
    }
  }

  public boolean logIn(HttpServletRequest request, HttpServletResponse response, String uname, String pass, String rem, String types) throws ServletException, IOException
  {
    PrintWriter out  = response.getWriter();
    response.setContentType("text/html;charset=UTF-8");
    //Getting the values from the form
    String get_name = uname;
    String get_pass = pass;
    String remember = rem;
    String type = types;
    String str  = new String("remember");
    String str1 = new String("null");

    Connection conn = null;
    PreparedStatement stmt = null;
    try{
       Class.forName("com.mysql.jdbc.Driver");
       conn = DriverManager.getConnection(DB_URL,USER,PASS);
       //Checking the user credintials to login
       stmt = conn.prepareStatement(String.format("SELECT * FROM "+ type +" WHERE uname = ? and pass = ?"));
       stmt.setString(1, get_name);
       stmt.setString(2, get_pass);
       ResultSet rs = stmt.executeQuery();
       if (rs.next()) {
         setEname(get_name);
         out.println("Success login");
         HttpSession session = request.getSession(true);
         session.setAttribute("USER", get_name);
         session.setAttribute("TYPE", type);
         //Remembering the user details in cookies
         if (remember.compareTo(str) == 0) {
           Cookie cookie  = new Cookie("Log_Bool", getEname());;
           Cookie cookie1 = new Cookie("Log_Type", type);
           cookie1.setMaxAge(60*60*24);
           cookie.setMaxAge(60*60*24);
           response.addCookie(cookie1);
           response.addCookie(cookie);
         } if (remember.compareTo(str1) == 0)
         {
           //out.println("You're logged in, but you are not saved your local credintials!");
         }
         response.sendRedirect("loginStatus.jsp?login=true");
         //response.sendRedirect("/finalRRTS");
       }else{
         response.sendRedirect("loginStatus.jsp?login=false");
         //out.println("Failed login");
       }
    }catch(SQLException se){
       out.println("SQL Exception occurred.........");
       //response.sendRedirect("errorSQL.jsp");
    }catch(Exception e){
      //out.println("Exception occurred .............");
      response.sendRedirect("loginStatus.jsp?login=true");
    }
    return true;

  }
  public LinkedList viewComplaint(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //In this method we are posting the Resident COmplaint
    boolean log_check = loginStatus(request, response);
    boolean isemployee= isEmployee(request, response);
    PrintWriter out = response.getWriter();

    LinkedList<Complaint> linklist = new LinkedList<Complaint>();

    Connection conn  = null;
    PreparedStatement stmt = null;
    LinkedList list = new LinkedList();
    if (true ) {
      if (true) {
        try {
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          stmt = conn.prepareStatement("SELECT * FROM Complaint");
          ResultSet rs = stmt.executeQuery();

          while (rs.next())
          {
            Complaint complaint = new Complaint();
            String comp_id   = (String)rs.getString(1);
            String comp_name = (String)rs.getString(2);
            String comp_desc = (String)rs.getString(3);
            String comp_rdno = (String)rs.getString(4);
            String comp_cond = (String)rs.getString(5);
            String comp_loc  = (String)rs.getString(6);

            complaint.setCid(comp_id);
            complaint.setCname(comp_name);
            complaint.setCdesc(comp_desc);
            complaint.setRdno(comp_rdno);
            complaint.setCond(comp_cond);
            complaint.setClocation(comp_loc);

            linklist.add(complaint);
          }
        } catch(SQLException se)
        {
          out.println("SQLException occurred....");
        } catch(Exception e)
        {
          out.println("Exception occurred//....");
        }
      } else {
        //Here we are redirecting if the user is not an employeee
        response.sendRedirect("login.jsp");
      }
    }else{
      //Here we are redirecting if the user is not logged in
      response.sendRedirect("login.jsp");
    }
    return linklist;
  }
  public boolean updateComplaint(HttpServletRequest request, HttpServletResponse response, String cid,
            String man1, String machine1, String cost1, String comp_desc, String status1) throws ServletException, IOException
  {
    //In this method we are posting the Resident Complaint
    boolean log_check = loginStatus(request, response);
    boolean isemployee= isEmployee(request, response);
    PrintWriter out = response.getWriter();

    int result=0;
    if (log_check) {
      if (isemployee) {
        Connection conn  = null;
        Connection conn2 = null;
        Connection conn1 = null;
        PreparedStatement stmt = null;
        PreparedStatement stmt1 = null;
        PreparedStatement stmt2 = null;

        HttpSession session = request.getSession(false);
        String type = (String)session.getAttribute("TYPE");
        String user = (String)session.getAttribute("USER");

        try{
          Class.forName("com.mysql.jdbc.Driver");
          conn  = DriverManager.getConnection(DB_URL, USER, PASS);
          conn1 = DriverManager.getConnection(DB_URL, USER, PASS);
          conn2 = DriverManager.getConnection(DB_URL, USER, PASS);

          String comp_id = cid;
          String man     = man1;
          String machine = machine1;
          String cost    = cost1;
          String desc    = comp_desc;
          String status  = status1;

          stmt = conn.prepareStatement("SELECT eid FROM Employee WHERE uname=?");
          stmt.setString(1, user);
          ResultSet rs = stmt.executeQuery();
          rs.next();
          int emp_id = rs.getInt(1);
          out.println(emp_id);

          stmt2 = conn2.prepareStatement("SELECT * FROM Complaint_Status WHERE comp_id=?");
          stmt2.setString(1, comp_id);
          ResultSet rs1 = stmt2.executeQuery();
          if (rs1.next()) {
            out.println("You are in the if condition");
            stmt1 = conn1.prepareStatement("UPDATE Complaint_Status SET comp_id=?, eid=?, comp_st_desc=?, comp_st_cost=?, status=?, man_power=?, machine_power=? WHERE comp_id=?");
            stmt1.setString(1, comp_id);
            stmt1.setInt(2, emp_id);
            stmt1.setString(3, desc);
            stmt1.setString(4, cost);
            stmt1.setString(5, status);
            //stmt1.setString(6, end_time);
            stmt1.setString(6, man);
            stmt1.setString(7, machine);
            stmt1.setString(8, comp_id);
            int q = 0;
            q = stmt1.executeUpdate();
            if (q != 0) {
              out.println("Updated ...");
              result = 1;
            }else{
              out.println("Not Updated ...");
            }
          }else{
            out.println("You are in the elsecondition");
            stmt1 = conn1.prepareStatement("INSERT INTO Complaint_Status(comp_id, eid, comp_st_desc, comp_st_cost, status,  man_power, machine_power) VALUES (?, ?, ?, ?, ?, ?, ?)");
            stmt1.setString(1, comp_id);
            stmt1.setInt(2, emp_id);
            stmt1.setString(3, desc);
            stmt1.setString(4, cost);
            stmt1.setString(5, status);
          //  stmt1.setString(6, end_time);
            stmt1.setString(6, man);
            stmt1.setString(7, machine);
            int q = 0;
            q = stmt1.executeUpdate();
            if (q != 0) {
              result = 1;
              out.println("Inserted ...");
            }else{
              out.println("Not Inserted ...");
            }
          }
        } catch(SQLException se)
        {
          out.println("SQLException occurred...");
        } catch(Exception e)
        {
          out.println("Exception occurred......");
        }
      }else{
        out.println("You are not an  employeee.....");
      }
    }else{
      out.println("You are not logged in......");
    }
    if (result == 1) {
      return true;
    }else{
      return false;
    }
  }
  public boolean requestRequire(HttpServletRequest request, HttpServletResponse response, String[] require,
            String[] quantity) throws ServletException, IOException
  {
    //In this method we are posting the Resident Complaint
    boolean log_check = loginStatus(request, response);
    boolean isemployee= isEmployee(request, response);
    PrintWriter out = response.getWriter();

    if (log_check) {
      if (isemployee) {
        Connection conn  = null;
        Connection conn1 = null;
        PreparedStatement stmt  = null;
        PreparedStatement stmt1 = null;
        PreparedStatement stmt2 = null;
        PreparedStatement stmt3 = null;
        try{
          Class.forName("com.mysql.jdbc.Driver");
          conn  = DriverManager.getConnection(DB_URL, USER, PASS);
          conn1 = DriverManager.getConnection(DB_URL, USER, PASS);

          HttpSession session = request.getSession(true);
          String username = (String)session.getAttribute("USER");
          out.println(username);
          out.println("<br/>Exception before first statement<br/>");
          stmt = conn.prepareStatement("SELECT * FROM Employee WHERE uname=?");
          stmt.setString(1, username);
          ResultSet rs = stmt.executeQuery();
          out.println("<br/>Exception after first statement<br/>");
          rs.next();
          int eid = rs.getInt(1);
          out.println("Eid is " + eid + "<br/> String len: "+require.length);

          for (int i=0; i<require.length; i++) {
            out.println("<br/>Exception before second statement<br/>");

            stmt2 = conn.prepareStatement("SELECT * FROM Emp_Req WHERE eid=? and req_id=?");
            stmt2.setInt(1, eid);
            stmt2.setString(2, require[i]);
            ResultSet rs1 = stmt2.executeQuery();
            if (rs1.next()) {
              out.println(rs1.getInt(5));
              int quant = Integer.parseInt(quantity[i]) + rs1.getInt(5);
              out.println("quantity :"+ quant);
              stmt3 = conn.prepareStatement("UPDATE Emp_Req SET quantity=? WHERE eid=? and req_id=?");
              stmt3.setInt(1, quant);
              stmt3.setInt(2, eid);
              stmt3.setString(3, require[i]);
              int w = 0;
              w = stmt3.executeUpdate();
              if (w != 0) {
                out.println("Update Success");
              }
            }else{
              //Here we are inserting the Requirements in the table
              stmt1 = conn1.prepareStatement("INSERT INTO Emp_Req (eid, req_id, quantity) VALUES (?, ?, ?)");
              stmt1.setInt(1, eid);
              stmt1.setString(2, require[i]);
              stmt1.setString(3, quantity[i]);
              int q = 0;
              q = stmt1.executeUpdate();
              out.println("<br/>Exception after second statement<br/>");
              if (q!=0 ) {
                out.println("<br/>Success<br/>");
              }
            }
          }
        }
        catch(SQLException se){
          out.println("SQLException occurred...");
        }
        catch(Exception e){
          out.println("Exception occurred......");
        }
      }else{
        out.println("You are not an Employeee.....");
      }
    }else{
      out.println("You are not logged in.....");
    }
    return true;
  }
  public boolean scheduleReport(HttpServletRequest request, HttpServletResponse response, String comp_id,
            String stDate,  String endDate ) throws ServletException, IOException
  {
    //In this method we are posting the Resident Complaint
    boolean log_check = loginStatus(request, response);
    boolean isemployee= isEmployee(request, response);
    PrintWriter out = response.getWriter();

    if (log_check) {
      if (isemployee) {
        Connection conn  = null;
        Connection conn1 = null;
        PreparedStatement stmt  = null;
        PreparedStatement stmt1 = null;
        PreparedStatement stmt2 = null;
        PreparedStatement stmt3 = null;
        try{
          Class.forName("com.mysql.jdbc.Driver");
          conn  = DriverManager.getConnection(DB_URL, USER, PASS);
          conn1 = DriverManager.getConnection(DB_URL, USER, PASS);

          HttpSession session = request.getSession(true);
          String username = (String)session.getAttribute("USER");
          out.println(username);

          stmt = conn.prepareStatement("INSERT INTO Schedule (sc_st_date, sc_end_date) VALUES (?, ?)");
          stmt.setString(1, stDate);
          stmt.setString(2, endDate);
          int q = 0;
          out.println("Gpood Bye to the wt;;;");
          q = stmt.executeUpdate();
          out.println("Welcome to the wt;;;");
          if (q != 0) {
            out.println("Schedule inserted successfully....");
            stmt1 = conn.prepareStatement("SELECT sc_id FROM Schedule WHERE sc_st_date=? and sc_end_date=?");
            stmt1.setString(1, stDate);
            stmt1.setString(2, endDate);
            ResultSet rs = stmt1.executeQuery();
            rs.next();
            String sc_id = rs.getString(1);

            stmt2 = conn.prepareStatement("SELECT eid FROM Employee WHERE uname=?");
            stmt2.setString(1, username);
            ResultSet rs1 = stmt2.executeQuery();
            rs1.next();
            String eid = rs1.getString(1);

            stmt3 = conn.prepareStatement("INSERT INTO Prepare VALUES (?, ?, ?)");
            stmt3.setString(1, comp_id);
            stmt3.setString(2, eid);
            stmt3.setString(3, sc_id);
            int w = 0;
            w = stmt3.executeUpdate();
            if (w != 0) {
              out.println("Schedule prepared successfully....");
            }else{
              out.println("Schedule not prepared../..........");
            }
          }

        }
        catch(SQLException se){
          out.println("SQLException occurred...");
        }
        catch(Exception e){
          out.println("Exception occurred......");
        }
      }else{
        out.println("You are not an Employeee.....");
      }
    }else{
      out.println("You are not logged in.....");
    }
    return true;
  }
  public LinkedList approvedRequests(HttpServletRequest request, HttpServletResponse response, String ename) throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();
    LinkedList<Requirements> linklist  = new LinkedList<Requirements>();

    if (loginStatus(request, response)) {
      if (isEmployee(request, response)) {

        Connection conn = null;
        PreparedStatement stmt  = null;
        PreparedStatement stmt1 = null;

        try{
          //Try statement will execute Hereout
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          stmt1 = conn.prepareStatement("SELECT * FROM Requirements");
          ResultSet rs1 = stmt1.executeQuery();
          LinkedList list = new LinkedList();
          while(rs1.next()){
            list.add(rs1.getString(2));
          }


          stmt1 = conn.prepareStatement("SELECT eid FROM Employee WHERE uname=?");
          stmt1.setString(1, ename);
          ResultSet rs2 = stmt1.executeQuery();
          rs2.next();
          int eid = rs2.getInt(1);

          stmt = conn.prepareStatement("SELECT * FROM Emp_Req WHERE eid=?");
          stmt.setInt(1, eid);
          ResultSet rs = stmt.executeQuery();
          while(rs.next()){
            Requirements req = new Requirements();
            String rid = (String)rs.getString("req_id");
            int quant = rs.getInt("quantity");
            int approved = rs.getInt("granted");

            String name = (String)list.get(Integer.parseInt(rid) - 1);
            req.setReq_name(name);
            req.setReq_id(rid);
            req.setQuantity(quant);
            req.setApproved(approved);
            linklist.add(req);
          }

        }catch(SQLException se){
          out.println("SQLException occurred...");
        }catch(Exception e){
          out.println("Exception occurred...");
        }

      }else{
        out.println("<br/>You are not an Employee to view this...");
      }
    }else{
      out.println("<br/>You are not logged in to view this.....");
    }
    return linklist;
  }
  public LinkedList viewAssignedComplaint(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //In this method we are posting the Resident COmplaint
    boolean log_check = loginStatus(request, response);
    boolean isemployee= isEmployee(request, response);
    PrintWriter out = response.getWriter();

    LinkedList<Complaint> linklist = new LinkedList<Complaint>();

    Connection conn  = null;
    PreparedStatement stmt  = null;
    LinkedList list = new LinkedList();
    if (true ) {
      if (true) {
        try {
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          HttpSession session = request.getSession(true);
          String uname = (String)session.getAttribute("USER");

          stmt = conn.prepareStatement("SELECT * FROM Complaint WHERE comp_id IN(SELECT comp_id FROM Assign WHERE eid IN(SELECT eid FROM Employee WHERE uname=?))");
          stmt.setString(1, uname);
          ResultSet rs = stmt.executeQuery();

          while (rs.next())
          {
            Complaint complaint = new Complaint();
            String comp_id   = (String)rs.getString(1);
            String comp_name = (String)rs.getString(2);
            String comp_desc = (String)rs.getString(3);
            String comp_rdno = (String)rs.getString(4);
            String comp_cond = (String)rs.getString(5);
            String comp_loc  = (String)rs.getString(6);

            complaint.setCid(comp_id);
            complaint.setCname(comp_name);
            complaint.setCdesc(comp_desc);
            complaint.setRdno(comp_rdno);
            complaint.setCond(comp_cond);
            complaint.setClocation(comp_loc);

            linklist.add(complaint);
          }
        } catch(SQLException se)
        {
          out.println("SQLException occurred....");
        } catch(Exception e)
        {
          out.println("Exception occurred//....");
        }
      } else {
        //Here we are redirecting if the user is not an employeee
        response.sendRedirect("login.jsp");
      }
    }else{
      //Here we are redirecting if the user is not logged in
      response.sendRedirect("login.jsp");
    }
    return linklist;
  }
}
