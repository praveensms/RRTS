import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ComplaintId extends HttpServlet
{
  static final String DB_Driver = "com.mysql.jdbc.Driver";
  static final String DB_Url = "jdbc:mysql://localhost/dbase";
  static final String DB_User = "root";
  static final String DB_Pass = "ammu";
  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
  {
    PrintWriter out = response.getWriter();
    response.setContentType("text/html");

    Employee emp = new Employee();
    if (emp.loginStatus(request, response)) {
      if (emp.isEmployee(request, response)) {
        Connection conn = null;
        PreparedStatement stmt = null;

        try{
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_Url, DB_User, DB_Pass);
          stmt = conn.prepareStatement("SELECT comp_id FROM Complaint WHERE comp_id NOT IN(SELECT comp_id FROM Prepare) AND comp_id NOT IN(SELECT comp_id FROM Complaint_Status WHERE status='Finished')");
          ResultSet rs = stmt.executeQuery();
          while (rs.next()) {
            String str = rs.getString(1);
            out.println(String.format("<option value=%s>%s</option>", str,str));
          }

        }catch(SQLException se){
          out.println("SQLException occurred....");
        }catch(Exception e){
          out.println("Exception occurred....");
        }
      }else{
        out.println("You are not Employee....");
      }
    }else{
      out.println("You are not logged in....");
    }

  }
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
  {
    processRequest(request, response);
  }
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
  {
    processRequest(request, response);
  }
}
