import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Mayor extends HttpServlet
{

  private String mid;
  private String mname;
  private String memail;
  private String mpass;
  private String mphno;

  //Setters
  public void setMid(String mid){
    this.mid = mid;
  }
  public void setMname(String Sname){
    this.mname = mname;
  }
  public void setMemail(String memail){
    this.memail = memail;
  }
  public void setMpass(String mpass){
    this.mpass = mpass;
  }
  public void setMphno(String mphno){
    this.mphno = mphno;
  }

  //Getters
  public String getMid(){
    return mid;
  }
  public String getMname(){
    return mname;
  }
  public String getMemail(){
    return memail;
  }
  public String getMpass(){
    return mpass;
  }
  public String getMphno(){
    return mphno;
  }

  static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
  static final String DB_URL = "jdbc:mysql://localhost/dbase";
  static final String USER = "root";
  static final String PASS = "ammu";

  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //Do Nothing
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }

  public boolean loginStatus(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    HttpSession sess = request.getSession(true);
    if (sess.getAttribute("USER") != null) {
      return true;
    }else{
      return false;
    }
  }

  public boolean isMayor(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    HttpSession sess = request.getSession(true);
    String userType = (String)sess.getAttribute("TYPE");
    if ( userType.compareTo("Administrator") == 0) {
      return true;
    }else{
      return false;
    }
  }

  public boolean logOut(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();
    HttpSession session = request.getSession(false);
    int flag1 = 1;
    if (session != null) {
        session.invalidate();
        flag1 = 2;
        //out.println("Success");
    }else{
      //out.println("Failed!");
      flag1 =0;
    }
    Cookie cookie    = null;
    Cookie [] cookies = null;
    int flag = 0;
    cookies = request.getCookies();
    String temp = null;
    if (cookies != null)
    {
      for (int i=0; i < cookies.length ; i++)
      {
        cookie = cookies[i];
        temp = cookie.getName();
        if ((temp).compareTo("Log_Bool") == 0 || (temp).compareTo("Log_Type") == 0) {
          cookie.setMaxAge(0);
          response.addCookie(cookie);
          flag = 5;
        }
      }
    }
    if (flag == 5 || flag1 == 2)
    {
      //out.println("you have successfully logged out!");
      response.sendRedirect("logout.jsp?logout=true");
      //out.println("Logged out successfully");
      return true;
    } else
    {
      //out.println("you have not logged out!");
      response.sendRedirect("logout.jsp?logout=false");
      //out.println("Logged out not success");
      return false;
    }
  }

  public boolean logIn(HttpServletRequest request, HttpServletResponse response, String uname, String pass, String rem, String types) throws ServletException, IOException
  {
    PrintWriter out  = response.getWriter();
    response.setContentType("text/html;charset=UTF-8");
    //Getting the values from the form
    String get_name = uname;
    String get_pass = pass;
    String remember = rem;
    String type = types;
    String str  = new String("remember");
    String str1 = new String("null");

    Connection conn = null;
    PreparedStatement stmt = null;
    try{
       Class.forName("com.mysql.jdbc.Driver");
       conn = DriverManager.getConnection(DB_URL,USER,PASS);
       //Checking the user credintials to login
       out.println("<br/>Before");
       stmt = conn.prepareStatement(String.format("SELECT * FROM Mayor WHERE uname = ? and pass = ?"));
       stmt.setString(1, get_name);
       stmt.setString(2, get_pass);
       ResultSet rs = stmt.executeQuery();
       out.println("<br/>Before after");
       if (rs.next()) {
         setMname(get_name);
         out.println("Success login");
         HttpSession session = request.getSession(true);
         session.setAttribute("USER", get_name);
         session.setAttribute("TYPE", type);
         //Remembering the user details in cookies
         if (remember.compareTo(str) == 0) {
           Cookie cookie  = new Cookie("Log_Bool", getMname());;
           Cookie cookie1 = new Cookie("Log_Type", type);
           cookie1.setMaxAge(60*60*24);
           cookie.setMaxAge(60*60*24);
           response.addCookie(cookie1);
           response.addCookie(cookie);
         } if (remember.compareTo(str1) == 0)
         {
           //out.println("You're logged in, but you are not saved your local credintials!");
         }
         response.sendRedirect("loginStatus.jsp?login=true");
         //response.sendRedirect("/finalRRTS");
       }else{
         response.sendRedirect("loginStatus.jsp?login=false");
         //out.println("Failed login");
       }
    }catch(SQLException se){
       out.println("SQL Exception occurred.........");
       //response.sendRedirect("errorSQL.jsp");
    }catch(Exception e){
      //out.println("Exception occurred .............");
      response.sendRedirect("loginStatus.jsp?login=true");
    }
    return true;

  }
  public LinkedList viewComplaint(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //In this method we are posting the Resident COmplaint
    boolean log_check = loginStatus(request, response);
    boolean isadministrator= isMayor(request, response);
    PrintWriter out = response.getWriter();

    LinkedList<Complaint> linklist = new LinkedList<Complaint>();

    Connection conn  = null;
    PreparedStatement stmt = null;
    LinkedList list = new LinkedList();
    if (true ) {
      if (true) {
        try {
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          stmt = conn.prepareStatement("SELECT * FROM Complaint");
          ResultSet rs = stmt.executeQuery();

          while (rs.next())
          {
            Complaint complaint = new Complaint();
            String comp_id   = (String)rs.getString(1);
            String comp_name = (String)rs.getString(2);
            String comp_desc = (String)rs.getString(3);
            String comp_rdno = (String)rs.getString(4);
            String comp_cond = (String)rs.getString(5);
            String comp_loc  = (String)rs.getString(6);

            complaint.setCid(comp_id);
            complaint.setCname(comp_name);
            complaint.setCdesc(comp_desc);
            complaint.setRdno(comp_rdno);
            complaint.setCond(comp_cond);
            complaint.setClocation(comp_loc);

            linklist.add(complaint);
          }
        } catch(SQLException se)
        {
          out.println("SQLException occurred....");
        } catch(Exception e)
        {
          out.println("Exception occurred//....");
        }
      } else {
        //Here we are redirecting if the user is not an Supervisor
        response.sendRedirect("login.jsp");
      }
    }else{
      //Here we are redirecting if the user is not logged in
      response.sendRedirect("login.jsp");
    }
    return linklist;
  }
}
