import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AssignComplaint extends HttpServlet
{

  static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
  static final String DB_URL = "jdbc:mysql://localhost/dbase";
  static final String USER = "root";
  static final String PASS = "ammu";

  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //Do Nothing
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();

    if (request.getParameter("submit") != null) {
      int empid = Integer.parseInt(request.getParameter("empid"));
      String compid = request.getParameter("compid");

      Supervisor sup = new Supervisor();
      boolean result = sup.assignComplaint(request, response, compid, empid);

      if (result) {
        out.println("Assigned complaint successfully");
      }else{
        out.println("Not Assigned successfully");
      }

    }else{
      out.println("You are not submitting any values to thesee<a href='..'>Click to Go HomePage</a>");
    }
  }
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }
}
