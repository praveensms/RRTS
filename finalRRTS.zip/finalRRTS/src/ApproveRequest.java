import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;

public class ApproveRequest extends HttpServlet {

	    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       PrintWriter out  = response.getWriter();
		   response.setContentType("text/html;charset=UTF-8");
			 //Getting the values from the form
       LinkedList<Requirements> linklist = new LinkedList<Requirements>();

       if (request.getParameter("submit") != null) {
         String[] approve = request.getParameterValues("approve");
         String[] req_id = request.getParameterValues("req_id");
         String[] quantity = request.getParameterValues("quantity");
         String eid = request.getParameter("eid");
         int i=0;
         while(i < approve.length){
           Requirements req = new Requirements();

           if (approve[i] != "") {
             out.println("You are if condition...");
             req.setReq_id(req_id[i]);
             req.setQuantity(Integer.parseInt(quantity[i]));
             req.setApproved(Integer.parseInt(approve[i]));
             linklist.add(req);
             out.println("Req_id  :" + req_id[i]);
             out.println("Quantity:" + quantity[i] + "<br/>");
             out.println("Approve :" + approve[i] + "<br/>");
             out.println("Employee id:" + eid + "<br/>");

             i++;
           }else{
             out.println("You are in else ...<br/>");
             i++;
           }
         }
         Supervisor sup = new Supervisor();
         boolean bool  = sup.approveRequest(request, response, linklist, (Integer.parseInt(eid)));
         if (bool) {
           out.println("Success");
         }else{
           out.println("not success");
         }
       }
	    }

	    @Override
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		        processRequest(request, response);
	    }
	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		      processRequest(request, response);
	    }
}
