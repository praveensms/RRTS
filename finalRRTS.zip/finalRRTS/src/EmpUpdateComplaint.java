import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class EmpUpdateComplaint extends HttpServlet
{
  static final String DB_Driver = "com.mysql.jdbc.Driver";
  static final String DB_Url = "jdbc:mysql://localhost/rrts";
  static final String DB_User = "root";
  static final String DB_Pass = "ammu";
  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
  {
    PrintWriter out = response.getWriter();
    response.setContentType("text/html");

    String comp_id = request.getParameter("cid");
    String man     = request.getParameter("man");
    String machine = request.getParameter("machine");
    String cost    = request.getParameter("cost");
    String desc    = request.getParameter("comp_desc");
    String status  = request.getParameter("status");

    Employee employee = new Employee();
    boolean result = employee.updateComplaint(request, response, comp_id, man, machine, cost, desc, status);

    if (result) {
      out.println("<br/>Inserted successfully.....");
    }else{
      out.println("<br/>Not Inserted successfully.....");
    }
  }
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
  {
    processRequest(request, response);
  }
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
  {
    processRequest(request, response);
  }
}
