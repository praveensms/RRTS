import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.lang.*;

public class PostFeedback extends HttpServlet {

	    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       PrintWriter out  = response.getWriter();
		   response.setContentType("text/html;charset=UTF-8");
			 //Getting the values from the form
       String desc = request.getParameter("feedback");
			 String rating = request.getParameter("rating");

			 Resident res = new Resident();
			 res.postFeedback(request, response, desc, rating);
	    }

	    @Override
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		        processRequest(request, response);
	    }
	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		      processRequest(request, response);
	    }
}
