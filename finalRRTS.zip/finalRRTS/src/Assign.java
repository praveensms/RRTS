import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Assign extends HttpServlet
{

  static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
  static final String DB_URL = "jdbc:mysql://localhost/dbase";
  static final String USER = "root";
  static final String PASS = "ammu";

  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //Do Nothing
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();

    Connection conn = null;
    PreparedStatement stmt  = null;
    PreparedStatement stmt1 = null;
    try{
      Class.forName("com.mysql.jdbc.Driver");
      conn = DriverManager.getConnection(DB_URL, USER, PASS);

      //Here EMployee details will be printed
      stmt = conn.prepareStatement("SELECT * FROM Employee");
      ResultSet rs = stmt.executeQuery();
      out.println("<select name='empid'>");
      out.println("<option selected disabled>Select Employee To Assign</option>");
      while(rs.next()){
        out.println("<option value="+ rs.getInt("eid") +">"+ rs.getInt(1) + " " + rs.getString("uname") + "</option>");
      }
      out.println("</select>");

      //Here Complaint id will goo
      stmt1 = conn.prepareStatement("SELECT comp_id FROM Complaint WHERE comp_id NOT IN(SELECT comp_id FROM Assign)");
      ResultSet rs1 = stmt1.executeQuery();
      out.println("<br/> <br/><select name='compid'>");
      out.println("<option selected disabled>Select Complaint To Assign</option>");
      while(rs1.next()){
        out.println("<option value="+ rs1.getInt("comp_id") +">"+ rs1.getInt("comp_id") + "</option>");
      }
      out.println("</select>");

    }catch(SQLException se){
      out.println("SQLException occurred.....");
    }catch(Exception e){
      out.println("Exception occurred.....");
    }
  }
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }
}
