import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Requirements extends HttpServlet
{

  private String req_id;
  private String req_name;
  private int quantity;
  private int approved;

  //Setters
  public void setReq_id(String req_id)
  {
    this.req_id = req_id;
  }
  public void setReq_name(String req_name)
  {
    this.req_name = req_name;
  }
  public void setQuantity(int quantity)
  {
    this.quantity = quantity;
  }
  public void setApproved(int approved)
  {
    this.approved = approved;
  }

  //Getters
  public String getReq_id()
  {
    return req_id;
  }
  public int getQuantity()
  {
    return quantity;
  }
  public String getReq_name()
  {
    return req_name;
  }
  public int getApproved()
  {
    return approved;
  }

  static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
  static final String DB_URL = "jdbc:mysql://localhost/dbase";
  static final String USER = "root";
  static final String PASS = "ammu";

  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //Do Nothing
  }
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //Do Nothing
    processRequest(request, response);
  }
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }
}
