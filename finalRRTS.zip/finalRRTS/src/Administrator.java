import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Administrator extends HttpServlet
{

  private String aid;
  private String aname;
  private String aemail;
  private String apass;
  private String aphno;

  //Setters
  public void setAid(String aid){
    this.aid = aid;
  }
  public void setAname(String Aname){
    this.aname = aname;
  }
  public void setAemail(String aemail){
    this.aemail = aemail;
  }
  public void setApass(String Spass){
    this.apass = apass;
  }
  public void setAphno(String aphno){
    this.aphno = aphno;
  }

  //Getters
  public String getAid(){
    return aid;
  }
  public String getAname(){
    return aname;
  }
  public String getAemail(){
    return aemail;
  }
  public String getApass(){
    return apass;
  }
  public String getAphno(){
    return aphno;
  }

  static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
  static final String DB_URL = "jdbc:mysql://localhost/dbase";
  static final String USER = "root";
  static final String PASS = "ammu";

  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //Do Nothing
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }

  public boolean loginStatus(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    HttpSession sess = request.getSession(true);
    if (sess.getAttribute("USER") != null) {
      return true;
    }else{
      return false;
    }
  }

  public boolean isAdministrator(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    HttpSession sess = request.getSession(true);
    String userType = (String)sess.getAttribute("TYPE");
    if ( userType.compareTo("Administrator") == 0) {
      return true;
    }else{
      return false;
    }
  }

  public boolean logOut(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();
    HttpSession session = request.getSession(false);
    int flag1 = 1;
    if (session != null) {
        session.invalidate();
        flag1 = 2;
        //out.println("Success");
    }else{
      //out.println("Failed!");
      flag1 =0;
    }
    Cookie cookie    = null;
    Cookie [] cookies = null;
    int flag = 0;
    cookies = request.getCookies();
    String temp = null;
    if (cookies != null)
    {
      for (int i=0; i < cookies.length ; i++)
      {
        cookie = cookies[i];
        temp = cookie.getName();
        if ((temp).compareTo("Log_Bool") == 0 || (temp).compareTo("Log_Type") == 0) {
          cookie.setMaxAge(0);
          response.addCookie(cookie);
          flag = 5;
        }
      }
    }
    if (flag == 5 || flag1 == 2)
    {
      //out.println("you have successfully logged out!");
      response.sendRedirect("logout.jsp?logout=true");
      //out.println("Logged out successfully");
      return true;
    } else
    {
      //out.println("you have not logged out!");
      response.sendRedirect("logout.jsp?logout=false");
      //out.println("Logged out not success");
      return false;
    }
  }

  public boolean logIn(HttpServletRequest request, HttpServletResponse response, String uname, String pass, String rem, String types) throws ServletException, IOException
  {
    PrintWriter out  = response.getWriter();
    response.setContentType("text/html;charset=UTF-8");
    //Getting the values from the form
    String get_name = uname;
    String get_pass = pass;
    String remember = rem;
    String type = types;
    String str  = new String("remember");
    String str1 = new String("null");

    Connection conn = null;
    PreparedStatement stmt = null;
    try{
       Class.forName("com.mysql.jdbc.Driver");
       conn = DriverManager.getConnection(DB_URL,USER,PASS);
       //Checking the user credintials to login
       stmt = conn.prepareStatement(String.format("SELECT * FROM "+ type +" WHERE uname = ? and pass = ?"));
       stmt.setString(1, get_name);
       stmt.setString(2, get_pass);
       ResultSet rs = stmt.executeQuery();
       if (rs.next()) {
         setAname(get_name);
         out.println("Success login");
         HttpSession session = request.getSession(true);
         session.setAttribute("USER", get_name);
         session.setAttribute("TYPE", type);
         //Remembering the user details in cookies
         if (remember.compareTo(str) == 0) {
           Cookie cookie  = new Cookie("Log_Bool", getAname());;
           Cookie cookie1 = new Cookie("Log_Type", type);
           cookie1.setMaxAge(60*60*24);
           cookie.setMaxAge(60*60*24);
           response.addCookie(cookie1);
           response.addCookie(cookie);
         } if (remember.compareTo(str1) == 0)
         {
           //out.println("You're logged in, but you are not saved your local credintials!");
         }
         response.sendRedirect("loginStatus.jsp?login=true");
         //response.sendRedirect("/finalRRTS");
       }else{
         response.sendRedirect("loginStatus.jsp?login=false");
         //out.println("Failed login");
       }
    }catch(SQLException se){
       out.println("SQL Exception occurred.........");
       //response.sendRedirect("errorSQL.jsp");
    }catch(Exception e){
      //out.println("Exception occurred .............");
      response.sendRedirect("loginStatus.jsp?login=true");
    }
    return true;

  }
  public LinkedList viewComplaint(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //In this method we are posting the Resident COmplaint
    boolean log_check = loginStatus(request, response);
    boolean isadministrator= isAdministrator(request, response);
    PrintWriter out = response.getWriter();

    LinkedList<Complaint> linklist = new LinkedList<Complaint>();

    Connection conn  = null;
    PreparedStatement stmt = null;
    LinkedList list = new LinkedList();
    if (true ) {
      if (true) {
        try {
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          stmt = conn.prepareStatement("SELECT * FROM Complaint");
          ResultSet rs = stmt.executeQuery();

          while (rs.next())
          {
            Complaint complaint = new Complaint();
            String comp_id   = (String)rs.getString(1);
            String comp_name = (String)rs.getString(2);
            String comp_desc = (String)rs.getString(3);
            String comp_rdno = (String)rs.getString(4);
            String comp_cond = (String)rs.getString(5);
            String comp_loc  = (String)rs.getString(6);

            complaint.setCid(comp_id);
            complaint.setCname(comp_name);
            complaint.setCdesc(comp_desc);
            complaint.setRdno(comp_rdno);
            complaint.setCond(comp_cond);
            complaint.setClocation(comp_loc);

            linklist.add(complaint);
          }
        } catch(SQLException se)
        {
          out.println("SQLException occurred....");
        } catch(Exception e)
        {
          out.println("Exception occurred//....");
        }
      } else {
        //Here we are redirecting if the user is not an Supervisor
        response.sendRedirect("login.jsp");
      }
    }else{
      //Here we are redirecting if the user is not logged in
      response.sendRedirect("login.jsp");
    }
    return linklist;
  }
  public LinkedList viewSRequest(HttpServletRequest request, HttpServletResponse response, String sid) throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();

    LinkedList<Requirements> linklist = new LinkedList<Requirements>();
    //Here we are checking if the user logged in or not
    if (loginStatus(request, response)) {
      //Here we are checking the user is Supervisor or not
      if (isAdministrator(request, response)) {
        Connection conn = null;
        PreparedStatement stmt  = null;
        PreparedStatement stmt1 = null;

        try{
          //Try statement will execute Hereout
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          stmt1 = conn.prepareStatement("SELECT * FROM Requirements");
          ResultSet rs1 = stmt1.executeQuery();
          LinkedList list = new LinkedList();
          while(rs1.next()){
            list.add(rs1.getString(2));
          }

          stmt = conn.prepareStatement("SELECT * FROM Sup_Req WHERE sid=?");
          stmt.setString(1, sid);
          ResultSet rs = stmt.executeQuery();
          while(rs.next()){
            Requirements req = new Requirements();
            String rid = (String)rs.getString("req_id");
            int quant = rs.getInt("quantity");
            String name = (String)list.get(Integer.parseInt(rid) - 1);
            req.setReq_name(name);
            req.setReq_id(rid);
            req.setQuantity(quant);
            linklist.add(req);
          }

        }catch(SQLException se){
          out.println("SQLException occurred...");
        }catch(Exception e){
          out.println("Exception occurred...");
        }
      }
    }else{
      out.println("You are not logged in......");
    }
    return linklist;
  }
  public LinkedList viewRSupervisor(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    //Completed
    PrintWriter out = response.getWriter();
    LinkedList<Supervisor> linklist = new LinkedList<Supervisor>();
    //Here we are checking if the user logged in or not
    if (loginStatus(request, response)) {
      //Here we are checking the user is Supervisor or not
      if (isAdministrator(request, response)) {
        Connection conn = null;
        PreparedStatement stmt = null;

        try{
          //Try statement will execute here
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          stmt = conn.prepareStatement("SELECT DISTINCT(sid) FROM Sup_Req");
          ResultSet rs = stmt.executeQuery();
          out.println("<br/> Administrator welcome you");
          while( rs.next() ){
            out.println("<br/> Administrator welcome you");
            Supervisor sup = new Supervisor();
            sup.setSid(rs.getString(1));
            linklist.add(sup);
          }

        }catch(SQLException se){
          out.println("SQLException occurred...");
        }catch(Exception e){
          out.println("Exception occurred...");
        }
      }
    }else{
      out.println("You are not logged in......");
    }
    return linklist;
  }
  public boolean approveRequest(HttpServletRequest request, HttpServletResponse response, LinkedList<Requirements> linklist,
                  int sid) throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();
    //Here we are checking if the user logged in or not
    if (loginStatus(request, response)) {
      //Here we are checking the user is Supervisor or not
      if (isAdministrator(request, response)) {
        Connection conn = null;
        PreparedStatement stmt  = null;
        PreparedStatement stmt1 = null;

        try{
          //Try statement will execute Hereout
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);

          HttpSession sess = request.getSession(true);
          String user = (String)sess.getAttribute("USER");
          stmt1 = conn.prepareStatement("SELECT aid from Administrator  WHERE uname=?");
          stmt1.setString(1, user);
          ResultSet rs = stmt1.executeQuery();
          rs.next();
          int aid = rs.getInt(1);

          int i =0;
          while (i < linklist.size()){
            Requirements req = new Requirements();
            req = linklist.get(i);
            String req_id = req.getReq_id();
            int quant  = req.getQuantity();
            int approve= req.getApproved();

            stmt = conn.prepareStatement("UPDATE Sup_Req SET ap_req=?, sid=?, granted=? WHERE sid=? and req_id=? and quantity=?");
            stmt.setString(1, "Approved");
            stmt.setInt(2, sid);
            stmt.setInt(3, approve);
            stmt.setInt(4, sid);
            stmt.setString(5, req_id);
            stmt.setInt(6, quant);
            out.println("<br/>Approve:"+"Approved");
            out.println("<br/>Sid:"+sid);
            out.println("<br/>Approve count:"+approve);
            out.println("<br/>Eid:"+sid);
            out.println("<br/>Req_id:"+req_id);
            out.println("<br/>Quantity:"+quant);
            int q = 0;
            q = stmt.executeUpdate();
            if (q!=0) {
              out.println("Updated....");
            }else{
              out.println("Not Updated....");
            }
            i++;
          }
        }catch(SQLException se){
          out.println("SQLException occurred...");
        }catch(Exception e){
          out.println("Exception occurred...");
        }
      }else{
        out.println("You are not supervisor...");
      }
    }else{
      out.println("You are not logged in......");
    }
    return true;
  }
}
