import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class EmpScheduleReport extends HttpServlet
{
  static final String DB_Driver = "com.mysql.jdbc.Driver";
  static final String DB_Url = "jdbc:mysql://localhost/dbase";
  static final String DB_User = "root";
  static final String DB_Pass = "ammu";
  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
  {
    PrintWriter out = response.getWriter();
    response.setContentType("text/html");

    Employee employee = new Employee();

    if (request.getParameter("submit") != null) {
      String compid = request.getParameter("compid");
      String stDate = request.getParameter("startdate");
      String endDate = request.getParameter("enddate");

      boolean result = employee.scheduleReport(request, response, compid, stDate, endDate);

      if (result) {
        out.println("<br/>Inserted successfully.....");
      }else{
        out.println("<br/>Not Inserted successfully.....");
      }
    }else{
      out.println("You are not submitting any values to this Method.....");
    }

  }
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
  {
    processRequest(request, response);
  }
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
  {
    processRequest(request, response);
  }
}
