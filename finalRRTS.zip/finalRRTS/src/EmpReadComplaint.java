import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class EmpReadComplaint extends HttpServlet
{
  static final String DB_Driver = "com.mysql.jdbc.Driver";
  static final String DB_Url = "jdbc:mysql://localhost/dbase";
  static final String DB_User = "root";
  static final String DB_Pass = "ammu";
  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    String comp_id  = request.getParameter("cid");

    Connection conn  = null;
    Connection conn1 = null;
    PreparedStatement stmt   = null;
    PreparedStatement stmt1  = null;
    PreparedStatement stmt2  = null;

    try {
      HttpSession sess = request.getSession(false);
      String user = (String)sess.getAttribute("USER");
      if (user == null) {
        response.sendRedirect("notLoggedIn.jsp");
      } else{
        Class.forName("com.mysql.jdbc.Driver");
        conn  = DriverManager.getConnection(DB_Url, DB_User, DB_Pass);
        conn1 = DriverManager.getConnection(DB_Url, DB_User, DB_Pass);

        stmt2 = conn.prepareStatement(String.format("SELECT dat FROM Posted WHERE comp_id=?"));
        stmt2.setString(1, comp_id);
        ResultSet rs3 = stmt2.executeQuery();
        rs3.next();

        if (user.compareTo("Resident") != 0) {
          stmt = conn1.prepareStatement(String.format("SELECT * FROM Complaint where comp_id=?"));
          stmt.setString(1, comp_id);
          ResultSet rs = stmt.executeQuery();
          out.println("<!DOCTYPE html>");
          out.println("<html>");
          out.println("<head>");
          out.println("<title>RRTS - Road Repair Tracking Service</title>");
          out.println("</head>");
          out.println("<body>");
          while (rs.next()) {
            out.println("<h1>");
            out.println(rs.getString(2));
            out.println("</h1><p><mark style='color:#9e4137; background-color:tan'>Complaint Id:</mark>");
            out.println(rs.getString(1));
            out.println("</p>");
            out.println("<br/><p>");
            out.println(rs.getString(3));
            out.println("</p><br/>");
            out.println("<p><mark style='color:#9e4137; background-color:tan'>Road No:</mark>");
            out.println(rs.getString(4));
            out.println("</p>");
            out.println("<p><mark style='color:#9e4137; background-color:tan'>Location:</mark>");
            out.println(rs.getString(6));
            out.println("</p>");
            out.println("<p><mark style='color:#9e4137; background-color:tan'>Condition:</mark>");
            out.println(rs.getString(5));
            out.println("</p>");
            out.println("<p><mark style='color:#9e4137; background-color:tan'>Raised On:</mark>");
            out.println(rs3.getString(1));
            out.println("</p>");
          }
          out.println("</body>");
          out.println("</html>");

          stmt.close();
          conn.close();
        } else {
          out.println("Error1: You are not authorized view this complaint....");
        }
      }
    } catch(SQLException se)
    {
      out.println("Error2: You are not authorized view this complaint....");
      //out.println("SQLException occurred.....\n");
    } catch (Exception e)
    {
      //Here we are redirecting to the notLoggedIn page
      out.println("Exception occurred........\n");
    }
  }
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }
}
