import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class RegCheck extends HttpServlet
{
  static final String DB_Driver = "com.mysql.jdbc.Driver";
  static final String DB_Url = "jdbc:mysql://localhost/dbase";
  static final String DB_User = "root";
  static final String DB_Pass = "ammu";
  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    PrintWriter out = response.getWriter();

    //Getting the Ipaddress
    String ipaddress= request.getHeader("X-FORWARDED-FOR");
    ipaddress = request.getRemoteAddr();

    String fnam = request.getParameter("fname");
    String lnam = request.getParameter("lname");
    String unam = request.getParameter("uname");
    String mail = request.getParameter("email");
    String pass = request.getParameter("pass");
    String type = request.getParameter("type");
    String phno = request.getParameter("ph_no");

    Connection conn = null;
    PreparedStatement stmt = null;
    PreparedStatement stmt1 = null;
    PreparedStatement stmt2 = null;
    PreparedStatement stmt3 = null;

    try {
      Class.forName("com.mysql.jdbc.Driver");
      conn = DriverManager.getConnection(DB_Url, DB_User, DB_Pass);

      int qs=0;
      if (type.compareTo("Resident") == 0) {
        //Here we are checking the existence of the resident
        out.println("Debug before stmt");
        stmt = conn.prepareStatement("SELECT * FROM Resident WHERE uname=?");
        stmt.setString(1, unam);
        out.println("Debug after stmt");
        out.println("Debug before stmt1");
        stmt1 = conn.prepareStatement("SELECT * FROM Resident WHERE remail=?");
        stmt1.setString(1, mail);
        out.println("Debug After stmt1");
        out.println("Debug before stmt2");
        stmt2 = conn.prepareStatement("SELECT * FROM Resident WHERE rph_no=?");
        stmt2.setString(1, phno);
        out.println("Debug After stmt2");

        ResultSet rs1 = stmt.executeQuery();
        ResultSet rs2 = stmt1.executeQuery();
        ResultSet rs3 = stmt2.executeQuery();

        if (rs1.next()) {
          out.println("User already existed in our database...");
        } else if (rs2.next()) {
          out.println("Email already existed in our database...");
        } else if (rs3.next()) {
          out.println("Phone Number already existed in our database...");
        } else {
          stmt3 = conn.prepareStatement("INSERT INTO Resident (rfname, rlname, uname, remail, pass, rph_no, ipaddress) VALUES (?, ?, ?, ?, ?, ?, INET_ATON(?))");
          stmt3.setString(1, fnam);
          stmt3.setString(2, lnam);
          stmt3.setString(3, unam);
          stmt3.setString(4, mail);
          stmt3.setString(5, pass);
          stmt3.setString(6, phno);
          stmt3.setString(7, ipaddress);
          int q = 0;
          q = stmt3.executeUpdate();
          if (q != 0) {
            out.println("Account created....");
          } else{
            out.println("Account not created welcdorjj....");
          }
        }
      }
      else {
          ipaddress = request.getRemoteAddr();
          if (ipaddress != null) {
            if (ipaddress.compareTo("127.0.0.1") == 0) {
              //out.println("It's ok, you are allowed to register with us\n");
              //String sql = String.format("INSERT INTO Account(fname, lname, uname, email, password, type, ph_no) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s')",fnam, lnam, unam, mail, pass, type, phno);
              if (type.compareTo("Clerk") == 0) {
                //String sql = String.format("INSERT INTO Clerk (cfname, clname, uname, cemail, pass, cph_no, ipaddress) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', INET_ATON('%s'))",fnam, lnam, unam, mail, pass, phno, ipaddress);
                stmt = conn.prepareStatement("INSERT INTO Clerk (cfname, clname, uname, cemail, pass, cph_no, ipaddress) VALUES (?, ?, ?, ?, ?, ?, INET_ATON(?))");
                stmt.setString(1, fnam);
                stmt.setString(2, lnam);
                stmt.setString(3, unam);
                stmt.setString(4, mail);
                stmt.setString(5, pass);
                stmt.setString(6, phno);
                stmt.setString(7, ipaddress);
              } else if (type.compareTo("Employee") == 0) {
                stmt = conn.prepareStatement("INSERT INTO Employee (efname, elname, uname, eemail, pass, eph_no, ipaddress) VALUES (?, ?, ?, ?, ?, ?,INET_ATON(?))");
                stmt.setString(1, fnam);
                stmt.setString(2, lnam);
                stmt.setString(3, unam);
                stmt.setString(4, mail);
                stmt.setString(5, pass);
                stmt.setString(6, phno);
                stmt.setString(7, ipaddress);
              } else if (type.compareTo("Supervisor") == 0) {
                stmt = conn.prepareStatement("INSERT INTO Supervisor (sfname, slname, uname, semail, pass, eph_no, ipaddress) VALUES (?, ?, ?, ?, ?, ?, INET_ATON(?))");
                stmt.setString(1, fnam);
                stmt.setString(2, lnam);
                stmt.setString(3, unam);
                stmt.setString(4, mail);
                stmt.setString(5, pass);
                stmt.setString(6, phno);
                stmt.setString(7, ipaddress);
              } else if (type.compareTo("Administrator") == 0) {
                stmt = conn.prepareStatement("INSERT INTO Administrator (afname, alname, uname, aemail, pass, aph_no, ipaddress) VALUES (?, ?, ?, ?, ?, ?, INET_ATON(?))");
                stmt.setString(1, fnam);
                stmt.setString(2, lnam);
                stmt.setString(3, unam);
                stmt.setString(4, mail);
                stmt.setString(5, pass);
                stmt.setString(6, phno);
                stmt.setString(7, ipaddress);
              } else{
                stmt = conn.prepareStatement("INSERT INTO Mayor (mfname, mlname, uname, memail, pass, mph_no, ipaddress) VALUES (?, ?, ?, ?, ?, ?,INET_ATON(?))");
                stmt.setString(1, fnam);
                stmt.setString(2, lnam);
                stmt.setString(3, unam);
                stmt.setString(4, mail);
                stmt.setString(5, pass);
                stmt.setString(6, phno);
                stmt.setString(7, ipaddress);
              }
              qs = stmt.executeUpdate();
            } else {
              out.println("You are not allowed to register with us\n");
            }
          }
          if (qs != 0){
            out.println("Account Created");
            //response.sendRedirect("login.jsp");
          } else {
            out.println("Account not created!........");
          }
        }
    } catch(SQLException se)
    {
      out.println("SQLException occurred.....\n");
    } catch (Exception e)
    {
      out.println("Exception occurred........\n");
    }
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
  {
    processRequest(request, response);
  }
}
